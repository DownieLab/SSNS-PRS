# Data and Directories

**Analyst:** Mahboobeh Norouzi
**Target cohort:** `combined_eur_sl_filtered` — N = 8,904 (961 SSNS cases, 7,943 controls)
**Ancestry:** European (EUR) + Sri Lankan (SL)
**Autosomes:** All 22 chromosomes
**SNPs:** 3,762,371 (after QC, restricted to Downie 2022 meta-analysis positions)

---

## 1. Input Data

### Target Genotype

| Path | Description |
|------|-------------|
| `/lustre09/project/6076774/mbhnzi/prs_ssns_final/data/combined_eur_sl_filtered.{bed,bim,fam}` | Final QC'd genotype (3,762,371 SNPs, N=8,904) |
| `/lustre09/project/6076774/mbhnzi/final_results/prs_v3/pca/pca_v3_20pc.eigenvec` | 20 genomic PCs (columns: FID, IID, PC1–PC20) |
| `/lustre09/project/6076774/mbhnzi/archive/agent1/multi_ancestry/pheno_combined.txt` | Phenotype (FID, IID, SSNS; 1=case, 0=control) |
| `/lustre09/project/6076774/mbhnzi/rebuild_v3/tmp/eur_ordered.txt` | EUR sample IDs (for CV stratification) |
| `/lustre09/project/6076774/mbhnzi/rebuild_v3/tmp/sl_keep_ordered.txt` | SL sample IDs (for CV stratification) |

### SSNS Discovery GWAS

| Path | Description |
|------|-------------|
| `/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/barry_hm3_qc.ma` | Barry et al. SSNS GWAS (GCST90258619), HapMap3 QC'd, N_eff=38,463 |

Columns: SNP (chr:pos), A1, A2, freq, b (log-OR), se, p, N (per-SNP effective N).

### Albuminuria Discovery GWAS

| Path | Description |
|------|-------------|
| `/lustre09/project/6076774/mbhnzi/prs_alb_final/results/alb_hm3_qc.ma` | Teumer + Brandenburg METAL meta-analysis, N up to 347,284 |

Per-SNP N used for LDpred2 QC (varies across SNPs because not all cohorts contributed to all variants). Fully independent of the target cohort.

---

## 2. PRS Output Directories

### SSNS PRS Score Files

| Path | Contents |
|------|----------|
| `prs_ssns_final/results/cv_filtered/simple_prs/simple_prs.sscore` | Simple PRS scores (N=8,904) |
| `prs_ssns_final/results/cv_filtered/ct_prs/ct_*.sscore` | C+T scores per threshold (11 files) |
| `prs_ssns_final/results/window_comparison/ssns_size1000/` | LDpred2 size=1000: auto, config1–4 `.sscore` + `*_params.tsv` + `chr_corr/chr*.rds` |
| `prs_ssns_final/results/window_comparison/ssns_size3000/` | LDpred2 size=3000: same structure |
| `prs_ssns_final/results/window_comparison/hla_test/` | HLA exclusion: `simple_hla_only.sscore`, `ct_0_001_hla_only.sscore`, HLA SNP list |

### ALB PRS Score Files

| Path | Contents |
|------|----------|
| `prs_alb_final/results/cv_filtered/simple_prs/simple_prs.sscore` | Simple PRS scores |
| `prs_alb_final/results/cv_filtered/ct_prs/ct_*.sscore` | C+T scores per threshold |
| `prs_ssns_final/results/window_comparison/alb_size1000/` | LDpred2 size=1000 for ALB |
| `prs_ssns_final/results/window_comparison/alb_size3000/` | LDpred2 size=3000 for ALB |

### Results and Logs

| Path | Contents |
|------|----------|
| `prs_ssns_final/results/window_comparison/eval_7030_results.tsv` | 70/30 primary results (Simple, C+T, LDpred2 Config1 size=3000) |
| `prs_ssns_final/results/window_comparison/simple_ct_20pc_results.tsv` | 5-fold CV: Simple PRS + C+T (both 10 and 20 PCs) |
| `prs_ssns_final/results/window_comparison/ldpred2_all_configs_7030.tsv` | 70/30 for all LDpred2 configs + window sizes |
| `prs_ssns_final/results/window_comparison/ct_all_thresholds.tsv` | C+T all thresholds (5-fold + 70/30) |
| `pub_repo/results/ldpred2_window_comparison.tsv` | Per-config best model (5-fold CV aggregate) for all configs + window sizes |
| `pub_repo/results/ldpred2_grid_full_comparison.tsv` | Full grid: all 688 individual model results (5-fold CV, 20 PCs) |
| `pub_repo/results/alb/hla_exclusion_results.tsv` | HLA exclusion: all methods × both eval approaches |
| `prs_ssns_final/logs/` | SLURM `.out` / `.err` files |

---

## 3. GitHub Repository

**URL:** `https://github.com/MahboobehNorouzi95/publication_ready_prs`

### Repo Structure

```
plots/
  forest_7030.png                           (forest plot — 70/30 test set)
  forest_5fold.png                          (forest plot — 5-fold CV aggregate OOF)
  roc_ssns_7030.png                         (SSNS ROC, PRS only, 70/30)
  roc_ssns_5fold.png                        (SSNS ROC, PRS only, 5-fold CV)
  roc_alb_7030.png                          (ALB ROC, PRS only, 70/30)
  roc_alb_5fold.png                         (ALB ROC, PRS only, 5-fold CV)
  ldpred2_heatmap.png                       (Config1 size=3000, SSNS+ALB side-by-side)
  manhattan_3panel.png
reports/
  01_DATA_AND_DIRECTORIES.md      (this file)
  02_PREPROCESSING_AND_QC.md
  03_METHODS.md
  04_CT_THRESHOLDS_AND_GRID.md
  05_RESULTS_AND_FIGURES.md
results/
  ssns/
    eval_7030_results.tsv
    simple_ct_5fold_results.tsv
  alb/
    hla_exclusion_results.tsv
  ldpred2_grid_full_comparison.tsv
  ldpred2_window_comparison.tsv
  ldpred2_all_configs_7030.tsv
  ct_all_thresholds.tsv
scripts/
  01_simple_prs.sh
  02_ct_prs.sh
  03_ldpred2_window_compare.R          (LDpred2: all configs + window sizes)
  03_ldpred2_window_compare_ssns.sh
  03_ldpred2_window_compare_alb.sh
  04_eval_7030_split.R
  05_hla_exclusion_eval.R
  05_hla_exclusion.sh
  compute_all_tables.R                  (C+T threshold table + Config3 heatmaps)
  eval_all_ldpred2_7030.R              (70/30 for all configs)
  generate_figures.R
  alb_00_prepare_ma.R / .sh
  alb_01_simple_prs.sh
  alb_02_ct_prs.sh
  alb/alb_cv_simple_ct.sh
  cv_simple_ct.sh
  gwas_batch_corrected.sh
  gwas_filtered.sh
  update_manhattan.R / .sh
SUMMARY.md
```

---

## 4. Cohort Construction

### European (EUR) Samples
Three source cohorts merged:
- **NEPTUNE**: Multi-site US/Canada nephrology cohort
- **PREDICT2**: UK prospective SSNS cohort
- **DUTCH** (incl. PRED2_NL): Dutch paediatric nephrology cohort

Batch covariate: EUR_other = 1 for DUTCH/PRED2_NL samples (N=494, 100% cases); used in target GWAS to correct chr15 allele frequency artifact.

### Sri Lankan (SL) Samples
Single-site Sri Lankan SSNS cohort.

### Merge and Liftover
Source genotypes on mixed builds (hg18/hg19/hg38) lifted to GRCh37 using UCSC LiftOver before merging. SNP IDs standardised to `chr:pos:ref:alt` format for merging, then mapped back to rsIDs using the target BIM.

---

## 5. Chr15 Recovery

EUR samples were missing chr15 after the initial merge. Root cause: EUR chr15 source VCFs used `chr15:pos:ref:alt` format while the shared BIM used rsIDs. No position-based fallback was applied during initial merge.

**Fix:** Re-extracted chr15 from 4 source VCFs (NEPTUNE, PREDICT2, DUTCH_A, DUTCH_B), applied a position-based ID remapping table, and re-merged chr15 into the combined dataset. QC re-run for chr15 only.

---

## 6. Principal Components

20 genomic PCs computed on `combined_eur_sl_filtered` using PLINK2 `--pca 20 approx`. Used in all final logistic regression models (OR, CI, P). Earlier versions used 10 PCs; all final results use 20 PCs.

PCA file: `pca_v3_20pc.eigenvec` — columns: FID, IID, PC1–PC20.
