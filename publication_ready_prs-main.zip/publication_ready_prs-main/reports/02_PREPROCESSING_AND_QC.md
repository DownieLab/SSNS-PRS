# Preprocessing and QC

---

## 1. SSNS Summary Statistics QC

Input: Barry et al. SSNS GWAS (GCST90258619), HapMap3 SNP set, N_eff = 38,463.

| Step | SNPs remaining | Filter |
|------|---------------:|--------|
| Raw HapMap3 download | 1,054,330 | All HapMap3 SNPs |
| Remove A/T and C/G ambiguous | 986,182 | Strand ambiguity |
| Remove MAF < 0.01 in target | 924,561 | Low-frequency |
| Remove INFO < 0.3 | 918,044 | Imputation quality |
| Match to target BIM (position + allele) | **658,392** | Final SSNS input |

Per-SNP N retained. Format: `chr:pos A1 A2 freq b se p N`.

---

## 2. Albuminuria Summary Statistics QC

Input: Teumer + Brandenburg METAL meta-analysis, N up to 347,284.

| Step | SNPs remaining | Filter |
|------|---------------:|--------|
| Raw METAL output | ~2,300,000 | All contributing SNPs |
| Remove A/T and C/G ambiguous | ~2,100,000 | Strand ambiguity |
| Remove MAF < 0.01 | ~1,900,000 | Low-frequency |
| Match to target BIM (position + allele) | **508,459** | Final ALB input |
| After C+T LD pruning (p≤0.001, r²<0.1) | 506 | C+T method only |
| After LDpred2 HapMap3 + correlation QC | **484,655** | LDpred2 method only |

Per-SNP N varies across SNPs (METAL output reflects cohort-specific inclusion per variant). Per-SNP N used in all LDpred2 QC steps.

---

## 3. Target Genotype QC

Starting from merged EUR + SL source genotypes:

| Step | SNPs | Samples | Action |
|------|-----:|--------:|--------|
| Initial merge | ~8,000,000 | 9,120 | Combined EUR + SL source genotypes |
| Restrict to autosomes | ~7,400,000 | 9,120 | Chr 1–22 only |
| Restrict to Downie 2022 positions | 3,920,000 | 9,120 | SSNS meta-analysis intersection |
| MAF < 0.01 | 3,800,000 | 9,120 | |
| SNP missingness > 0.05 | 3,780,000 | 9,120 | |
| Sample missingness > 0.05 | 3,780,000 | 8,904 | Remove low-call-rate samples |
| HWE p < 1×10⁻⁶ (controls only) | **3,762,371** | **8,904** | Final target genotype |

**Final target genotype:** 3,762,371 SNPs, N = 8,904 (961 cases, 7,943 controls).

---

## 4. Chr15 Recovery

EUR samples were originally missing chr15 after the initial merge.

**Root cause:** EUR chr15 source VCFs used a `chr15:pos:ref:alt` SNP ID format; the target BIM used rsIDs. The merge step used SNP ID matching (not position-based matching), so no EUR chr15 SNPs were retained.

**Fix:**
1. Re-extracted chr15 from 4 source VCFs (NEPTUNE, PREDICT2, DUTCH_A, DUTCH_B)
2. Converted SNP IDs using a position-based remapping table (position → rsID from dbSNP build 151)
3. Re-merged chr15 into the combined EUR+SL dataset
4. Re-applied QC filters for the recovered chromosome

**Impact without fix:** LDpred2 LD matrix for chr15 was computed on SL-only genotypes, inflating the per-SNP h² estimates for chr15 variants.

---

## 5. Chr15 Batch Artifact and Correction

After chr15 recovery, a genome-wide significant cluster appeared on chr15 in the target GWAS (p ~ 10⁻¹⁰¹ for multiple SNPs). Investigation:

**Diagnosis:**
- EUR_other batch (DUTCH/PRED2_NL, N=494): 100% SSNS cases
- Chr15 allele frequencies in EUR_other 3–4× higher than in controls
- Result: chr15 variants are case-enriched due to batch composition, not due to genetic association with SSNS

**Mechanism:** PLINK2 logistic regression detected the allele frequency difference between EUR_other (all cases) and the remaining cohorts (mixed), producing spurious p-values.

**Fix:** Add a binary `EUR_other` covariate to the logistic regression model:

```bash
plink2 --bfile combined_eur_sl_filtered \
  --logistic hide-covar \
  --covar pca_v3_20pc.eigenvec \
  --covar-col-nums 3-22 \
  --covar $EUR_OTHER_COVAR \
  ...
```

The EUR_other covariate absorbs the batch-level allele frequency difference. After correction, the chr15 cluster collapses to p > 0.05.

Script: `scripts/gwas_batch_corrected.sh`.

---

## 6. LDpred2 Per-SNP QC

Applied inside the LDpred2 pipeline after SNP matching:

**Step 1: MAF filter**
```r
maf  <- snp_MAF(G, ind.col = df_beta$`_NUM_ID_`)
keep <- maf > (1 / sqrt(nrow(G)))
```
Removes SNPs with MAF below the minimum for reliable correlation estimates (threshold ≈ 0.011 for N=8,904).

**Step 2: SD consistency filter**
```r
sd_y   <- quantile(sqrt(0.5*(n_eff * beta_se^2 + beta^2)), 0.01)
sd_ss  <- sd_y / sqrt(n_eff * beta_se^2 + beta^2)
is_bad <- sd_ss < (0.5*sd_val) | sd_ss > (sd_val+0.1) | sd_ss < 0.05 | sd_val < 0.05
```
Removes SNPs where the implied SD of genotype dosages from summary statistics is inconsistent with the observed SD in the target genotype. Identifies SNPs with incorrect allele frequencies, allele flips, or gross N misspecification.

**Step 3: χ² filter**
Removes SNPs with non-finite or zero chi-squared (beta/se)².

Final counts after LDpred2 QC:
- SSNS: 658,392 → **586,299 SNPs**
- ALB: 508,459 → **484,655 SNPs**

---

## 7. HLA Region Definition

chr6:25,000,000–34,000,000 (GRCh37). Covers:
- HLA class I: HLA-A (6:29,913,037–29,979,854), HLA-B (6:31,321,649–31,324,989), HLA-C (6:31,236,526–31,239,879)
- HLA class II: HLA-DR (6:32,439,842–33,143,440), HLA-DQ (6:32,627,244–32,936,551), HLA-DP (6:33,043,703–33,057,473)
- HLA class III: complement genes, TNF (6:31,543,350–32,666,533)

Identification in target BIM:
```bash
awk '$1==6 && $4>=25000000 && $4<=34000000 {print $2}' combined_eur_sl_filtered.bim
```

HLA SNP counts per method:
- Simple PRS: **4,431** SNPs (of 508,459 total ALB SNPs)
- C+T (p≤0.001): **14** SNPs (of 506 after LD pruning at r²<0.1)
- LDpred2: **4,362** SNPs (of 484,655 after QC)

The large difference between Simple PRS (4,431) and C+T (14) reflects LD pruning: in LD-pruned sets, only one representative per LD block is retained, so most HLA SNPs are removed as redundant with a single representative.

---

## 8. Heritability Estimates (LDSC, from LDpred2 pipeline)

| Analysis | LD window | h²_LDSC (init) |
|----------|:---------:|:--------------:|
| SSNS | 1000 | 0.0934 |
| SSNS | 3000 | 0.0757 |
| ALB | 1000 | 0.0237 |
| ALB | 3000 | ~0.008 (unstable) |

These are per-SNP h² estimates for HapMap3 SNPs in the target population, not the full heritability. Config multipliers (0.5–1.5×) are applied to explore uncertainty around these estimates.
