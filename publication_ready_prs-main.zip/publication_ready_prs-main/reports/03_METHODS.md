# Methods

---

## 1. Simple PRS

Weighted sum of all QC-filtered GWAS SNPs. Each SNP's weight is its GWAS effect size (log-OR from logistic regression or beta from linear regression). Computed with PLINK2 `--score`.

- SSNS: 658,392 SNPs
- ALB: 508,459 SNPs

No LD pruning or p-value thresholding. Script: `scripts/01_simple_prs.sh`.

---

## 2. Clumping + Thresholding (C+T)

**Clumping:** PLINK2 LD pruning (r² < 0.1 in 250-kb windows) on the full set of GWAS SNPs matched to target genotype. Done once per analysis (SSNS and ALB separately), producing a set of approximately independent representative SNPs.

**Primary threshold (pre-specified):** p<5×10⁻⁸ (genome-wide significance), matching the discovery GWAS threshold used in Tu et al. 2026 (*Kidney International*). This threshold is pre-specified — no model selection, no data-driven tuning. Evaluated on all N=8,904; no train/test split needed.

- SSNS: 38 SNPs
- ALB: 11 SNPs (all on chr1, 2, 4, 12, 14, 15 — none in HLA region)

**Full threshold sweep (supplementary):** Thresholds 5×10⁻⁸, 1×10⁻⁶, 1×10⁻⁵, 1×10⁻⁴, 5×10⁻⁴, 0.001, 0.01, 0.05, 0.1, 0.5, 1.0 evaluated on all N=8,904 for context. Results in Table 3 (SUMMARY.md) and `reports/04_CT_THRESHOLDS_AND_GRID.md`.

Scripts: `scripts/02_ct_prs.sh` (score computation), `scripts/eval_ct_5e8.R` (evaluation).

---

## 3. LDpred2-Grid

### 3.1 SNP Matching and QC

Summary statistics (SSNS: GCST90258619; ALB: METAL meta-analysis) matched to target BIM by chromosome + position + allele. Post-match QC filters applied to each SNP:

1. MAF > 1/√N (where N = median per-SNP N)
2. SD check: 0.5 × SD_val < SD_ss < SD_val + 0.1 and SD_ss > 0.05 and SD_val > 0.05
3. χ² > 0 (finite beta/SE)

Final SNP counts after QC:
- SSNS: 586,299 SNPs
- ALB: 484,655 SNPs

### 3.2 Per-Chromosome LD Matrix

Sparse LD correlation matrix computed from the target genotype using `snp_cor()`:

```r
corr0 <- snp_cor(G, ind.col = ind_col, size = SIZE, ncores = 1)
```

- `size = 1000`: ±1,000 SNPs window (tested)
- `size = 3000`: ±3,000 SNPs window (tested)

**Window rationale:** Size=3000 covers ~8 Mb in the HLA region (typical LD extends 4 Mb on each side). In practice, AUC is identical between window sizes (0.749 vs 0.751 for SSNS Config3); size=3000 ensures the full extended MHC LD structure is captured.

**Per-chromosome RDS checkpointing:** Each chromosome's sparse LD matrix saved as `chr_corr/chr{01-22}.rds`. SFBM rebuilt from these files at the start of each run. This allows SLURM jobs to resume after hitting 24-hour wall time without recomputing LD.

```r
for (chr in 1:22) {
  chr_rds <- file.path(CHR_DIR, sprintf('chr%02d.rds', chr))
  if (file.exists(chr_rds)) { corr0 <- readRDS(chr_rds); next }
  corr0 <- snp_cor(G, ind.col = ind_col, size = SIZE, ncores = 1)
  saveRDS(corr0, chr_rds, compress = FALSE)
}
```

### 3.3 LDSC Heritability Estimation

SNP heritability estimated via LDpred2's built-in LDSC implementation:

```r
ldsc <- snp_ldsc(ld_all, length(ld_all), chi2 = (beta/beta_se)^2,
                 sample_size = n_eff, blocks = NULL)
h2 <- ldsc[['h2']]
```

If h² is NA, ≤0, or >1.5, a default of 0.05 is used. Per-SNP N (`n_eff`) is used throughout — not a scalar.

### 3.4 Grid Configurations

| Config | p values | h² multipliers (× h²_LDSC) | sparse | Models |
|--------|----------|:---------------------------:|:------:|:------:|
| Config1 | {1×10⁻⁴, 1×10⁻³, 0.01, 0.1} | {0.7, 1.0, 1.3} | {FALSE} | 12 |
| Config2 | {1×10⁻⁴, 1×10⁻³, 0.01, 0.1} | {0.7, 1.0, 1.3} | {FALSE, TRUE} | 24 |
| Config3 | {1×10⁻⁵, 5×10⁻⁵, 1×10⁻⁴, 5×10⁻⁴, 1×10⁻³, 5×10⁻³, 0.01, 0.05, 0.1, 0.2, 0.5} | {0.5, 0.7, 1.0, 1.3, 1.5} | {FALSE, TRUE} | 110 |
| Config4 | {1×10⁻⁶, 5×10⁻⁶, 1×10⁻⁵, 5×10⁻⁵, 1×10⁻⁴} | {0.3, 0.5, 0.7, 1.0, 1.3} | {TRUE} | 25 |

Models are generated as `expand.grid(p, h2, sparse)`.

### 3.5 LDpred2-Auto

Automatic estimation using 30 MCMC chains:

```r
multi_auto <- snp_ldpred2_auto(corr, df_beta, h2_init = h2,
                                vec_p_init = seq_log(1e-4, 0.2, 30), ncores = 1)
```

Chains filtered by stability: keep chains where |h²_est − median(h²_est)| < 3 × MAD(h²_est). Final PRS = mean of beta vectors from kept chains.

**Config4 failure (SSNS):** Very small p combined with sparse=TRUE produced all-zero beta estimates (MCMC did not find causal variants). Not a numerical error — indicates the SSNS genetic architecture is inconsistent with extremely sparse priors.

**Auto failure (ALB size=3000):** All 30 chains returned NaN h². The low ALB h²_LDSC (~0.008 for size=3000) fell below the numerical stability threshold of the LDSC implementation at this LD window scale.

### 3.6 PRS Score Computation

```r
beta_grid <- snp_ldpred2_grid(corr, df_beta, params, ncores = 1)
scores    <- big_prodMat(G, beta_grid, ind.col = df_beta$`_NUM_ID_`, ncores = 1)
```

Scores saved as tab-delimited `.sscore` files (columns: FID, IID, PRS_1 ... PRS_k). Models that did not converge produce all-zero or NA columns.

Script: `scripts/03_ldpred2_window_compare.R`.

### 3.7 Per-SNP N

Per-SNP effective sample size is used throughout (LDSC h² estimation, allele frequency QC). For SSNS (single GWAS), N varies by SNP based on cohort-level missingness. For ALB (METAL meta-analysis), N varies substantially across SNPs because different cohorts contributed different variants. Using per-SNP N (vs a scalar) is critical for ALB to avoid miscalibrated heritability estimates.

---

## 4. Evaluation Design

### 4.1 Evaluation Design by Method

**Simple PRS:** Evaluated on all N=8,904. No split — no model selection is performed.

**C+T p<5×10⁻⁸:** Evaluated on all N=8,904. No split — threshold is pre-specified, not data-selected. No overfitting possible.

**LDpred2:** Uses 5-fold CV aggregate OOF for model selection and evaluation.

### 4.2 5-Fold CV Aggregate Out-of-Fold (LDpred2 only)

**Fold assignment:** 4-way stratified by EUR/SL × case/control (seed=42). Each stratum's samples randomly assigned to 5 folds with approximately equal sizes.

**Per-fold model selection:** For each fold k, best LDpred2 hyperparameter (p, h² multiplier) selected by PRS-only AUC on the 4 training folds (k≠fold). OOF predictions stored for fold k.

**Aggregate evaluation:** All N=8,904 OOF predictions concatenated. One logistic regression on all OOF data:

```r
df <- data.frame(y = oof_y[ok], prs = scale(oof_score[ok])[,1], pc_df[ok,])
fit <- glm(y ~ ., data = df, family = binomial())
co  <- unname(coef(summary(fit))['prs',])
```

OR = exp(β), CI = exp(β ± 1.96 × SE), P = two-sided Wald test.

**Why aggregate OOF (not per-fold average):** OR, CI, and P must come from the same model. Averaging OR, CI_lo, CI_hi, and P separately across 5 folds produces internally inconsistent statistics: CI endpoints can exclude 1.0 while P remains large (because each fold's SE differs). One regression on concatenated OOF predictions guarantees internal consistency.

Script: `scripts/eval_ct_5e8.R` (Simple PRS + C+T all thresholds); `scripts/03_ldpred2_window_compare_ssns.sh` / `03_ldpred2_window_compare_alb.sh` (LDpred2).

### 4.3 Evaluation Metrics

| Metric | Definition | Notes |
|--------|------------|-------|
| AUC (PRS only) | `pROC::roc(outcome, raw_PRS)$auc` | No PCs. Sample-size-invariant. |
| AUC (PRS + 20 PCs) | `pROC::roc(outcome, fitted(glm))$auc` | From 20-PC model. |
| OR (per SD) | `exp(β_PRS)` from logistic regression | PRS standardized to mean=0, SD=1. |
| 95% CI | `exp(β ± 1.96 × SE)` | Wald-based. |
| P-value | Two-sided Wald test | From `coef(summary(glm))['prs', 4]`. |

---

## 5. HLA Exclusion Methodology

**Purpose:** Test whether ALB PRS signal on SSNS outcome comes from HLA cross-trait pleiotropy (chr6:25,000,000–34,000,000, GRCh37).

**Simple PRS and C+T:** PLINK2 computes the HLA-only score contribution:

```bash
plink2 --bfile combined_eur_sl_filtered \
  --score alb_hm3_qc.ma 1 2 5 header-read \
  --extract hla_snps_bim.txt \
  --out hla_only_score
```

HLA SNP IDs from target BIM: `awk '$1==6 && $4>=25000000 && $4<=34000000 {print $2}'`. The HLA-only score is subtracted from the full score to produce the non-HLA PRS.

**LDpred2:** The chr6 LD matrix is rebuilt excluding HLA rows and columns before fitting:

```r
if (chr == 6) {
  hla_within <- which(df_beta$pos[ind_chr] >= 25e6 & df_beta$pos[ind_chr] <= 34e6)
  keep_within <- setdiff(seq_len(length(ind_chr)), hla_within)
  corr0 <- corr0[keep_within, keep_within, drop = FALSE]
}
```

The resulting PRS inherently excludes HLA contributions (no subtraction needed).

Both approaches evaluated in 5-fold CV aggregate and 70/30 split with 20 PCs.

HLA SNP counts: Simple PRS = 4,431; C+T p<5×10⁻⁸ = 0 (all 11 ALB GWS SNPs are outside HLA — HLA exclusion not applicable); LDpred2 = 4,362.

Each method uses the same model as the main Tables 1–2 result (no additional model selection for HLA exclusion).

Script: `scripts/05_hla_exclusion_eval.R` / `scripts/05_hla_exclusion.sh`.

---

## 6. Target GWAS (Batch-Corrected)

Within-cohort GWAS run for Manhattan plot visualization (not used for PRS; discovery GWAS summary statistics used for PRS weights). Model: PLINK2 logistic regression with 20 PCs + EUR_other binary batch covariate (absorbs chr15 allele frequency artifact in DUTCH/PRED2 samples). 3,762,371 SNPs, N=8,904.

Script: `scripts/gwas_batch_corrected.sh`.
