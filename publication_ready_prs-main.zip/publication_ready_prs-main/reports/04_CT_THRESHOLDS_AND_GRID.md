# Supplementary Tables — C+T Thresholds, LDpred2 Grid, Evaluation Comparison

## Primary C+T Result: Pre-specified p<5×10⁻⁸

The primary C+T analysis uses a pre-specified genome-wide significance threshold (p<5×10⁻⁸), matching Tu et al. 2026 (*Kidney International*). No model selection. Evaluated on all N=8,904.

| Analysis | SNPs | AUC | OR | 95% CI | P-value |
|----------|-----:|----:|---:|--------|---------|
| SSNS — C+T p<5×10⁻⁸ | 38 | 0.732 | 2.283 | 2.094–2.489 | 4.7×10⁻⁷⁸ |
| ALB — C+T p<5×10⁻⁸ | 11 | 0.534 | 1.009 | 0.932–1.092 | 0.827 |

ALB at GWS is **perfectly null** (OR=1.009, P=0.827). All 11 ALB GWS SNPs are on chromosomes 1, 2, 4, 12, 14, 15 — none are in the HLA region (chr6:25–34 Mb). The GWS C+T score is already HLA-free.

The tables below show the full sweep across thresholds for additional context.

---

---

## Table 5A — SSNS C+T: All Thresholds (all N=8,904, 20 PCs)

Each threshold evaluated on all N=8,904 (no split; thresholds are not data-selected here). **Primary analysis uses p<5×10⁻⁸** (pre-specified). The 5-fold CV column was computed as aggregate OOF on all N=8,904 using consistent methodology.

| Threshold | SNPs | AUC | OR | 95% CI | P-value |
|-----------|-----:|----:|---:|--------|---------|
| **5×10⁻⁸** ★ | **38** | **0.732** | **2.283** | **2.094–2.489** | **4.7×10⁻⁷⁸** |
| 1×10⁻⁶ | 48 | 0.730 | 2.183 | 2.008–2.375 | 2.6×10⁻⁷⁴ |
| 1×10⁻⁵ | 73 | 0.734 | 2.214 | 2.031–2.414 | 1.2×10⁻⁷² |
| 1×10⁻⁴ | 136 | 0.737 | 2.246 | 2.059–2.450 | 2.3×10⁻⁷⁴ |
| 5×10⁻⁴ | 314 | 0.734 | 2.186 | 2.005–2.384 | 6.1×10⁻⁷⁰ |
| 0.001 | 500 | 0.732 | 2.248 | 2.055–2.459 | 6.4×10⁻⁷⁰ |
| 0.01 | 2,614 | 0.700 | 2.729 | 2.407–3.094 | 2.4×10⁻⁵⁵ |
| 0.05 | 9,447 | 0.689 | 3.199 | 2.751–3.721 | 1.7×10⁻⁵¹ |
| 0.1 | 16,146 | 0.690 | 3.483 | 2.963–4.094 | 8.9×10⁻⁵² |
| 0.5 | 46,539 | 0.689 | 3.594 | 3.043–4.244 | 2.1×10⁻⁵¹ |
| 1.0 (all) | 61,835 | 0.689 | 3.591 | 3.040–4.243 | 4.6×10⁻⁵¹ |

★ Primary analysis. SSNS AUC is stable (0.73–0.74) at GWS thresholds.

The large OR at liberal thresholds (0.1–1.0) with lower AUC is expected: noise SNPs inflate score variance, increasing OR (per SD) while reducing discrimination. AUC is the appropriate metric.

---

## Table 5B — ALB C+T: All Thresholds (all N=8,904, 20 PCs)

| Threshold | SNPs | AUC | OR | 95% CI | P-value |
|-----------|-----:|----:|---:|--------|---------|
| **5×10⁻⁸** ★ | **11** | **0.534** | **1.009** | **0.932–1.092** | **0.827** |
| 1×10⁻⁶ | 18 | 0.537 | 0.982 | 0.908–1.063 | 0.659 |
| 1×10⁻⁵ | 48 | 0.567 | 0.906 | 0.836–0.983 | 0.017 |
| 1×10⁻⁴ | 134 | 0.582 | 0.874 | 0.804–0.951 | 0.0018 |
| 5×10⁻⁴ | 315 | 0.553 | 0.846 | 0.783–0.914 | 2.2×10⁻⁵ |
| 0.001 | 506 | 0.555 | 0.836 | 0.774–0.903 | 5.6×10⁻⁶ |
| 0.01 | 2,630 | 0.547 | 0.891 | 0.825–0.962 | 0.0030 |
| 0.05 | 8,287 | 0.493 | 0.911 | 0.842–0.986 | 0.021 |
| 0.1 | 13,528 | 0.507 | 0.945 | 0.872–1.024 | 0.168 |
| 0.5 | 36,563 | 0.495 | 0.931 | 0.859–1.009 | 0.082 |
| 1.0 (all) | 47,989 | 0.508 | 0.930 | 0.858–1.009 | 0.082 |

★ Primary analysis. **ALB at p<5×10⁻⁸ is perfectly null** (OR=1.009, P=0.827). All 11 SNPs are non-HLA.

AUC is near chance (0.49–0.58) across all thresholds — no meaningful discriminative ability for any ALB C+T threshold. The inverse OR signal emerging below p<1×10⁻⁵ reflects accumulation of HLA-correlated sub-threshold variants (HLA cross-trait pleiotropy). See `plots/ct_threshold_sweep.png`.

---

## Table 6A — SSNS LDpred2 Config3 Full Grid (size=3000, 5-fold CV aggregate, 20 PCs)

60 of 110 models converged (remaining 50 had insufficient signal at very small p with very small h²). Top 30 models by AUC shown; all 60 valid results in `results/ldpred2_grid_full_comparison.tsv`.

| Rank | Model# | p (causal) | h² × h²_LDSC | sparse | AUC | OR | 95% CI | P |
|------|-------:|-----------|:------------:|:------:|----:|---:|--------|---|
| 1 | 61 | 0.005 | 0.038 | TRUE | 0.759 | 2.846 | 2.580–3.139 | 3.4×10⁻⁹⁷ |
| 1 | 6 | 0.005 | 0.038 | FALSE | 0.759 | 2.947 | 2.664–3.260 | 8.2×10⁻⁹⁸ |
| 3 | 72 | 0.005 | 0.053 | TRUE | 0.754 | 2.745 | 2.492–3.024 | 7.9×10⁻⁹³ |
| 3 | 62 | 0.01 | 0.038 | TRUE | 0.754 | 3.205 | 2.874–3.574 | 2.8×10⁻⁹⁷ |
| 3 | 17 | 0.005 | 0.053 | FALSE | 0.754 | 2.741 | 2.488–3.020 | 1.0×10⁻⁹² |
| 6 | 7 | 0.01 | 0.038 | FALSE | 0.753 | 3.096 | 2.781–3.447 | 1.5×10⁻⁹⁴ |
| 7 | 84 | 0.01 | 0.076 | TRUE | 0.752 | 2.862 | 2.588–3.165 | 6.0×10⁻⁹³ |
| 7 | 73 | 0.01 | 0.053 | TRUE | 0.752 | 3.013 | 2.712–3.346 | 4.4×10⁻⁹⁴ |
| 9 | 29 | 0.01 | 0.076 | FALSE | 0.750 | 2.889 | 2.606–3.202 | 1.4×10⁻⁹⁰ |
| 9 | 18 | 0.01 | 0.053 | FALSE | 0.750 | 3.019 | 2.715–3.357 | 1.7×10⁻⁹² |
| 11 | 83 | 0.005 | 0.076 | TRUE | 0.748 | 2.641 | 2.401–2.905 | 1.3×10⁻⁸⁸ |
| 12 | 95 | 0.01 | 0.098 | TRUE | 0.747 | 2.746 | 2.486–3.033 | 2.3×10⁻⁸⁸ |
| 13 | 28 | 0.005 | 0.076 | FALSE | 0.746 | 2.644 | 2.401–2.912 | 7.3×10⁻⁸⁷ |
| 14 | 40 | 0.01 | 0.098 | FALSE | 0.743 | 2.654 | 2.406–2.928 | 1.3×10⁻⁸⁴ |
| 15 | 51 | 0.01 | 0.114 | FALSE | 0.742 | 2.630 | 2.385–2.900 | 1.3×10⁻⁸³ |
| 15 | 39 | 0.005 | 0.098 | FALSE | 0.742 | 2.536 | 2.309–2.786 | 8.2×10⁻⁸⁴ |
| 15 | 106 | 0.01 | 0.114 | TRUE | 0.742 | 2.628 | 2.384–2.897 | 3.2×10⁻⁸⁴ |
| 18 | 94 | 0.005 | 0.098 | TRUE | 0.738 | 2.454 | 2.238–2.691 | 1.8×10⁻⁸¹ |
| 19 | 96 | 0.05 | 0.098 | TRUE | 0.734 | 2.732 | 2.457–3.038 | 4.6×10⁻⁷⁷ |
| 19 | 85 | 0.05 | 0.076 | TRUE | 0.734 | 2.906 | 2.601–3.247 | 3.5×10⁻⁷⁹ |
| 21 | 50 | 0.005 | 0.114 | FALSE | 0.733 | 2.389 | 2.181–2.616 | 1.2×10⁻⁷⁸ |
| 22 | 107 | 0.05 | 0.114 | TRUE | 0.732 | 2.709 | 2.437–3.011 | 4.0×10⁻⁷⁶ |
| 23 | 74 | 0.05 | 0.053 | TRUE | 0.731 | 3.076 | 2.737–3.458 | 3.7×10⁻⁷⁹ |
| 24 | 63 | 0.05 | 0.038 | TRUE | 0.730 | 3.142 | 2.789–3.538 | 2.3×10⁻⁷⁹ |
| 24 | 105 | 0.005 | 0.114 | TRUE | 0.730 | 2.356 | 2.151–2.581 | 8.3×10⁻⁷⁶ |
| 26 | 30 | 0.05 | 0.076 | FALSE | 0.728 | 2.650 | 2.383–2.947 | 3.1×10⁻⁷² |
| 27 | 41 | 0.05 | 0.098 | FALSE | 0.727 | 2.536 | 2.288–2.811 | 1.8×10⁻⁷⁰ |
| 27 | 19 | 0.05 | 0.053 | FALSE | 0.727 | 2.750 | 2.464–3.070 | 1.4×10⁻⁷² |
| 27 | 108 | 0.1 | 0.114 | TRUE | 0.727 | 2.623 | 2.360–2.916 | 1.9×10⁻⁷¹ |
| 30 | 97 | 0.1 | 0.098 | TRUE | 0.726 | 2.708 | 2.429–3.018 | 3.6×10⁻⁷² |

Best model: p=0.005, h²=0.038×h²_LDSC, sparse=TRUE (or sparse=FALSE — tied AUC=0.759). Full 60-model table: see `results/ldpred2_grid_full_comparison.tsv`.

---

## Table 6B — ALB LDpred2 Config3 Full Grid (size=3000, 5-fold CV aggregate, 20 PCs)

82 of 110 models converged. Top 20 models shown; all results in `results/ldpred2_grid_full_comparison.tsv`.

| Rank | Model# | p (causal) | h² × h²_LDSC | sparse | AUC | OR | 95% CI | P |
|------|-------:|-----------|:------------:|:------:|----:|---:|--------|---|
| 1 | 3 | 1×10⁻⁴ | 0.007 | FALSE | 0.546 | 0.916 | 0.848–0.990 | 0.027 |
| 1 | 102 | 1×10⁻⁴ | 0.020 | TRUE | 0.546 | 0.934 | 0.864–1.009 | 0.084 |
| 3 | 80 | 1×10⁻⁴ | 0.013 | TRUE | 0.545 | 0.926 | 0.858–1.001 | 0.052 |
| 3 | 47 | 1×10⁻⁴ | 0.020 | FALSE | 0.545 | 0.934 | 0.865–1.009 | 0.085 |
| 5 | 69 | 1×10⁻⁴ | 0.009 | TRUE | 0.544 | 0.923 | 0.855–0.997 | 0.042 |
| 5 | 57 | 5×10⁻⁵ | 0.007 | TRUE | 0.544 | 0.930 | 0.861–1.005 | 0.065 |
| 7 | 91 | 1×10⁻⁴ | 0.017 | TRUE | 0.543 | 0.934 | 0.865–1.009 | 0.084 |
| 7 | 36 | 1×10⁻⁴ | 0.017 | FALSE | 0.543 | 0.940 | 0.870–1.015 | 0.115 |
| 7 | 13 | 5×10⁻⁵ | 0.009 | FALSE | 0.543 | 0.933 | 0.864–1.008 | 0.078 |
| 10 | 2 | 5×10⁻⁵ | 0.007 | FALSE | 0.542 | 0.949 | 0.878–1.025 | 0.182 |
| 10 | 14 | 1×10⁻⁴ | 0.009 | FALSE | 0.542 | 0.927 | 0.858–1.002 | 0.055 |
| 12 | 68 | 5×10⁻⁵ | 0.009 | TRUE | 0.541 | 0.941 | 0.871–1.017 | 0.123 |
| 12 | 58 | 1×10⁻⁴ | 0.007 | TRUE | 0.541 | 0.930 | 0.861–1.005 | 0.066 |
| 12 | 25 | 1×10⁻⁴ | 0.013 | FALSE | 0.541 | 0.933 | 0.864–1.008 | 0.078 |
| 15 | 90 | 5×10⁻⁵ | 0.017 | TRUE | 0.539 | 0.950 | 0.880–1.026 | 0.194 |
| 15 | 79 | 5×10⁻⁵ | 0.013 | TRUE | 0.538 | 0.942 | 0.872–1.017 | 0.129 |
| 15 | 35 | 5×10⁻⁵ | 0.017 | FALSE | 0.538 | 0.947 | 0.876–1.022 | 0.162 |
| 15 | 101 | 5×10⁻⁵ | 0.020 | TRUE | 0.538 | 0.947 | 0.876–1.022 | 0.163 |
| 19 | 6 | 0.005 | 0.007 | FALSE | 0.537 | 0.904 | 0.837–0.977 | 0.010 |
| 19 | 24 | 5×10⁻⁵ | 0.013 | FALSE | 0.537 | 0.950 | 0.880–1.026 | 0.191 |

AUC ranges from 0.53 to 0.55 across all models — near chance. No Config3 model provides meaningful discrimination for ALB. Full results: `results/ldpred2_grid_full_comparison.tsv`.

---

## Table 7 — Evaluation Method Comparison (ALB, all methods, 20 PCs)

Same PRS scores, same samples, different evaluation N. Demonstrates that OR is stable; statistical significance depends on sample size.

| Method | Eval approach | N | AUC (PRS only) | OR | 95% CI | P | CI crosses 1.0? |
|--------|:-------------:|--:|---------------:|---:|--------|---|:---------------:|
| Simple PRS | 5-fold CV agg. | 8,904 | 0.523 | 0.881 | 0.815–0.951 | 0.0013 | No |
| Simple PRS | 70/30 test | 2,671 | 0.503 | 0.917 | 0.798–1.053 | 0.219 | **Yes** |
| C+T (p≤1×10⁻⁴) | 5-fold CV agg. | 8,904 | 0.582 | 0.874 | 0.804–0.951 | 0.00182 | No |
| C+T (p≤1×10⁻⁴) | 70/30 test | 2,671 | 0.582 | 0.850 | 0.729–0.992 | 0.039 | **Yes (barely)** |
| LDpred2 Config1 | 5-fold CV agg. | 8,904 | 0.543 | 0.929 | 0.861–1.004 | 0.063 | Barely (p=0.063) |
| LDpred2 Config1 | 70/30 test | 2,671 | 0.509 | 0.928 | 0.808–1.067 | 0.296 | **Yes** |

**C+T:** p≤1×10⁻⁴ selected by 5-fold CV training AUC (OR=0.874, 5-fold; OR=0.850, 70/30). Both evaluation approaches use the same best threshold. The 70/30 OR is nearly identical, confirming the effect estimate is stable across evaluation designs.

**Interpretation:** The OR is stable (~0.88–0.93) across all approaches. At N=8,904, confidence intervals narrow enough to exclude 1.0 for most methods. At N=2,671, they do not. PRS-only AUC (0.50–0.58) is sample-size-invariant and is the unambiguous evidence of near-chance discriminative ability across all methods.
