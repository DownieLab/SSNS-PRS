# Results and Figures

**Target genotype:** `combined_eur_sl_filtered`, N=8,904 (961 SSNS cases, 7,943 controls), EUR+SL ancestry, 3,762,371 SNPs.  
**Covariates:** 20 genomic PCs for all OR/CI/P estimates.

**Evaluation design by method:**
- Simple PRS: all N=8,904, no split, no model selection
- C+T p<5×10⁻⁸: all N=8,904, no split; threshold pre-specified (Tu et al. 2026, *Kidney International*)
- LDpred2 Config1: 5-fold CV aggregate OOF on all N=8,904; model selection on training folds only

---

## Table 1 — SSNS PRS (all N=8,904, 20 PCs)

| Method | SNPs | AUC (PRS only) | OR (20 PCs) | 95% CI | P-value |
|--------|-----:|:--------------:|------------:|--------|---------|
| Simple PRS | 658,392 | 0.707 | 3.456 | 2.999–3.982 | 7.3×10⁻⁶⁶ |
| C+T p<5×10⁻⁸ | 38 | 0.732 | 2.283 | 2.094–2.489 | 4.7×10⁻⁷⁸ |
| LDpred2 Config1 (size=3000) | 586,299 | 0.750 | 2.939 | 2.648–3.261 | 9.1×10⁻⁹² |

LDpred2 best model: PRS_3 (p=0.01, h²=0.7×h²_LDSC=0.053, sparse=FALSE).  
Source: `results/ssns/simple_ct_5fold_results.tsv`, `results/ldpred2_window_comparison.tsv`.

---

## Table 2 — ALB PRS on SSNS outcome (all N=8,904, 20 PCs)

Cross-trait negative control. Expected: null (no genetic overlap between albuminuria and SSNS).

| Method | SNPs | AUC (PRS only) | OR (20 PCs) | 95% CI | P-value |
|--------|-----:|:--------------:|------------:|--------|---------|
| Simple PRS | 508,459 | 0.523 | 0.881 | 0.815–0.951 | 0.001 |
| C+T p<5×10⁻⁸ | 11 | 0.534 | 1.009 | 0.932–1.092 | 0.827 |
| LDpred2 Config1 (size=3000) | 484,655 | 0.543 | 0.929 | 0.861–1.004 | 0.063 |

**C+T p<5×10⁻⁸:** Perfectly null (OR=1.009, P=0.827). 11 SNPs, all non-HLA.  
**LDpred2:** Null (P=0.063, CI crosses 1.0). Best model: PRS_1 (p=1×10⁻⁴, h²=0.7×h²_LDSC=0.0094).  
**Simple PRS:** Statistically significant (P=0.001) due to large N=8,904, but AUC=0.523 confirms no discriminative ability. Signal is HLA cross-trait pleiotropy — see Table 3.

Source: `results/ssns/simple_ct_5fold_results.tsv`, `results/ldpred2_window_comparison.tsv`.

---

## Table 3 — HLA Exclusion (ALB PRS evaluated on SSNS outcome, all N=8,904, 20 PCs)

HLA region: chr6:25,000,000–34,000,000 (GRCh37).  
Each method uses the same model as Table 2 (no additional model selection for HLA exclusion).

| Method | HLA SNPs | OR (with HLA) | P | 95% CI | OR (no HLA) | P | 95% CI |
|--------|--------:|-------------:|--:|--------|------------:|--:|--------|
| Simple PRS | 4,431 | 0.881 | 0.001 | 0.815–0.951 | 0.965 | 0.370 | 0.893–1.043 |
| C+T p<5×10⁻⁸ | 0 | 1.009 | 0.827 | 0.932–1.092 | N/A | N/A | N/A |
| LDpred2 Config1 (PRS_1) | 4,362 | 0.929 | 0.063 | 0.861–1.004 | 0.967 | 0.391 | 0.895–1.044 |

**Simple PRS (no HLA):** OR=0.965, P=0.370 — fully null. The inverse association is entirely attributable to 4,431 HLA SNPs.

**C+T p<5×10⁻⁸ HLA exclusion:** NOT APPLICABLE. All 11 ALB GWS SNPs are on chr1, 2, 4, 12, 14, 15 — none in HLA. The score is already HLA-free and was already null (OR=1.009).

**LDpred2 (no HLA):** OR=0.967, P=0.391 — fully null. HLA betas zeroed in PRS_1 betas before scoring.

Source: `results/alb/hla_exclusion_results.tsv`.

---

## Figures

### Figure 1 — SSNS ROC (all N=8,904, PRS score only)

![SSNS ROC](../plots/roc_ssns.png)

Three curves: Simple PRS (#2980B9, AUC=0.707), C+T p<5×10⁻⁸ (#E67E22, AUC=0.732), LDpred2 Config1 size=3000 (#2C3E50, AUC=0.750).

### Figure 2 — ALB ROC (all N=8,904, PRS score only)

![ALB ROC](../plots/roc_alb.png)

Three curves: Simple PRS (#2980B9, AUC=0.523), C+T p<5×10⁻⁸ (#E67E22, AUC=0.534), LDpred2 Config1 size=3000 (#2C3E50, AUC=0.543). All methods near the diagonal — no discriminative ability.

### Figure 3 — Forest Plot

![Forest Plot](../plots/forest_plot.png)

OR [95% CI] per SD PRS (log scale), 20 PCs. Three groups: SSNS (strong positive), ALB with HLA (weak inverse), ALB without HLA (null). C+T p<5×10⁻⁸ "without HLA" = same as "with HLA" (0 HLA SNPs in the score).

### Figure 4 — C+T Threshold Sweep

![C+T Threshold Sweep](../plots/ct_threshold_sweep.png)

OR per SD PRS (20 PCs) across all p-value thresholds, all N=8,904. SSNS (blue) is stable at ~2.2–2.3 across GWS thresholds. ALB (red) is null at p<5×10⁻⁸ (OR=1.009) and moves toward OR≈0.84 as HLA-correlated variants enter at permissive thresholds. The inverse ALB signal is entirely a threshold artifact — it appears only when sub-threshold HLA-correlated variants are included.

### Figure 5 — LDpred2 Config1 Heatmap

![LDpred2 Heatmap](../plots/ldpred2_heatmap.png)

AUC across 12 hyperparameter combinations (4 p × 3 h² multipliers, sparse=FALSE) for SSNS and ALB. ★ = best model. SSNS best: PRS_3 (p=0.01, 0.7×h²_LDSC, AUC=0.750). ALB best: PRS_1 (p=1×10⁻⁴, 0.7×h²_LDSC, AUC=0.543).

### Figure 6 — Manhattan Plot

![Manhattan](../plots/manhattan_3panel.png)

Target cohort GWAS (batch-corrected). N=8,904, 3,762,371 SNPs, 20 PCs + EUR_other batch covariate. Genome-wide significance: p=5×10⁻⁸.

---

## Scientific Interpretation

**SSNS:** All three methods confirm a strong, replicable SSNS PRS (OR=2.3–3.5, AUC=0.71–0.75). LDpred2 achieves the highest AUC (0.750) by optimally shrinking thousands of SNPs. C+T at GWS (OR=2.283) is comparable to simple PRS (AUC=0.707) despite using only 38 SNPs.

**ALB:** The cross-trait negative control is confirmed. At the pre-specified GWS threshold, ALB C+T is perfectly null (OR=1.009, P=0.827). LDpred2 is null (P=0.063). Simple PRS shows a statistically significant inverse association (P=0.001) but AUC=0.523 reveals this is not biologically meaningful — HLA exclusion confirms the signal is entirely HLA cross-trait pleiotropy.

**Key conclusion:** There is no evidence of a shared genetic basis between albuminuria and SSNS. The apparent ALB inverse signal in permissive C+T thresholds and Simple PRS is attributable to HLA cross-trait pleiotropy, not true genetic correlation. The pre-specified GWS C+T analysis — the most statistically rigorous comparison — is perfectly null.
