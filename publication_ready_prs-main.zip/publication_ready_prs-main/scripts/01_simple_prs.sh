#!/bin/bash
#SBATCH --job-name=simple_ssns_hm3_qc
#SBATCH --account=def-mdownie
#SBATCH --time=02:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=12G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/simple_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/simple_%j.err

set -euo pipefail

PGEN_PREFIX=/lustre09/project/6076774/mbhnzi/rebuild_v3/combined_eur_sl_v3_final
GWAS=/lustre09/project/6076774/mbhnzi/archive/agent1/ssns_only_corrected_meta/ssns_corrected_hm3_qc.ma
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/simple_prs

mkdir -p $OUTDIR
module load plink/2.00-20231024-avx2

echo "Start: $(date)"
plink2 --bfile $PGEN_PREFIX \
       --score $GWAS 1 2 5 header-read \
       --out $OUTDIR/simple --memory 11000
echo "End: $(date)"
echo "=== Simple PRS done ==="
