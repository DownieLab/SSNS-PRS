#!/bin/bash
#SBATCH --job-name=ct_ssns_hm3_qc
#SBATCH --account=def-mdownie
#SBATCH --time=06:00:00
#SBATCH --cpus-per-task=2
#SBATCH --mem=18G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/ct_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/ct_%j.err

set -euo pipefail

PGEN_PREFIX=/lustre09/project/6076774/mbhnzi/rebuild_v3/combined_eur_sl_v3_final
GWAS=/lustre09/project/6076774/mbhnzi/archive/agent1/ssns_only_corrected_meta/ssns_corrected_hm3_qc.ma
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/ct_prs

mkdir -p $OUTDIR

echo "=== Clumping ==="
module load plink/2.00a5.8
awk 'BEGIN{OFS="\t"} NR==1 {print "SNP","P"} NR>1 {print $1, $7}' $GWAS > $OUTDIR/gwas_for_clump.txt

plink2 --bfile $PGEN_PREFIX \
       --clump $OUTDIR/gwas_for_clump.txt \
       --clump-r2 0.1 --clump-kb 250 --clump-p1 1.0 \
       --out $OUTDIR/clumped \
       --threads 2 --memory 16000

module purge
module load plink/2.00-20231024-avx2

THRESHOLDS="5e-8 1e-6 1e-5 1e-4 5e-4 0.001 0.002 0.01 0.02 0.05 0.1 0.5 1.0"
awk 'NR>1 {print $3}' $OUTDIR/clumped.clumps > $OUTDIR/clumped_snps.txt

echo "=== Scoring ==="
for THRESH in $THRESHOLDS; do
    awk -v t=$THRESH 'BEGIN{OFS="\t"}
    NR==FNR { snps[$1]=1; next }
    FNR==1 { print; next }
    ($1 in snps) && ($7+0 <= t+0) { print }
    ' $OUTDIR/clumped_snps.txt $GWAS > $OUTDIR/ct_thresh_${THRESH}.ma

    NSNP=$(tail -n +2 $OUTDIR/ct_thresh_${THRESH}.ma | wc -l)
    if [ "$NSNP" -gt 0 ]; then
        plink2 --bfile $PGEN_PREFIX \
               --score $OUTDIR/ct_thresh_${THRESH}.ma 1 2 5 header-read \
               --out $OUTDIR/ct_${THRESH} --memory 16000
    fi
done

echo "End: $(date)"
echo "=== C&T done ==="
