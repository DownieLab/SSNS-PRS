#!/usr/bin/env Rscript
# Unified LDpred2 window-size comparison
# Usage: Rscript ldpred2_window_compare.R <PHENO> <SIZE>
#   PHENO: SSNS or ALB
#   SIZE:  1000 or 3000
# Runs LDpred2-auto + 4 grid configs. Per-chromosome RDS checkpointing for resume.
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({
  library(bigsnpr); library(bigsparser); library(data.table)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2) stop('Usage: ldpred2_window_compare.R <PHENO> <SIZE>')
PHENO <- args[1]
SIZE  <- as.integer(args[2])
stopifnot(PHENO %in% c('SSNS', 'ALB'), SIZE %in% c(1000L, 3000L))

BASE <- '/lustre09/project/6076774/mbhnzi'
BED  <- file.path(BASE, 'prs_ssns_final/data/combined_eur_sl_filtered')

if (PHENO == 'SSNS') {
  MA_FILE   <- file.path(BASE, 'prs_ssns_final/results/barry_hm3_qc.ma')
  CKPT_BETA <- file.path(BASE, 'prs_ssns_final/results/cv_filtered/ldpred2/ckpt_df_beta_qc.rds')
} else {
  MA_FILE   <- file.path(BASE, 'prs_alb_final/results/alb_hm3_qc.ma')
  CKPT_BETA <- file.path(BASE, 'prs_alb_final/results/cv_filtered/ldpred2/ckpt_df_beta_qc.rds')
}

OUTDIR  <- file.path(BASE, 'prs_ssns_final/results/window_comparison',
                     sprintf('%s_size%d', tolower(PHENO), SIZE))
CHR_DIR <- file.path(OUTDIR, 'chr_corr')
NCORES  <- 1L

dir.create(OUTDIR,  recursive = TRUE, showWarnings = FALSE)
dir.create(CHR_DIR, recursive = TRUE, showWarnings = FALSE)

cat(sprintf('=== LDpred2 window comparison: PHENO=%s SIZE=%d — %s ===\n',
            PHENO, SIZE, Sys.time()))

# Early exit if all outputs exist
all_done <- all(file.exists(file.path(OUTDIR,
  c(paste0('config', 1:4, '.sscore'), 'auto.sscore'))))
if (all_done) { cat('All outputs exist — nothing to do.\n'); quit(save = 'no') }

# ── Step 1: Attach bigsnpr ────────────────────────────────────────────────────
rds_file <- paste0(BED, '.rds')
if (!file.exists(rds_file)) snp_readBed(paste0(BED, '.bed'))
obj <- snp_attach(rds_file)
G   <- obj$genotypes; map_geno <- obj$map
cat(sprintf('Genotypes: %d samples, %d SNPs\n', nrow(G), ncol(G)))

# ── Step 2: SNP matching + QC (reuse checkpoint if available) ────────────────
local_ckpt <- file.path(OUTDIR, 'ckpt_df_beta_qc.rds')
if (file.exists(local_ckpt)) {
  df_beta <- readRDS(local_ckpt)
  cat(sprintf('df_beta from local checkpoint: %d SNPs\n', nrow(df_beta)))
} else if (file.exists(CKPT_BETA)) {
  df_beta <- readRDS(CKPT_BETA)
  cat(sprintf('df_beta from shared checkpoint: %d SNPs\n', nrow(df_beta)))
  saveRDS(df_beta, local_ckpt)
} else {
  cat('Computing df_beta from scratch...\n')
  ss <- fread(MA_FILE)
  setnames(ss, c('SNP', 'A1', 'A2', 'freq', 'b', 'se', 'p', 'N'))
  sumstats <- data.frame(
    chr=as.integer(sub(':.*', '', ss$SNP)), pos=as.integer(sub('.*:', '', ss$SNP)),
    a0=ss$A2, a1=ss$A1, beta=ss$b, beta_se=ss$se, n_eff=ss$N, freq=ss$freq)
  map <- data.frame(
    chr=as.integer(map_geno$chromosome), pos=as.integer(map_geno$physical.pos),
    a0=map_geno$allele2, a1=map_geno$allele1)
  df_beta <- snp_match(sumstats, map, join_by_pos = TRUE)
  df_beta <- df_beta[complete.cases(df_beta[, c('beta','beta_se','n_eff','freq')]), ]
  df_beta <- df_beta[is.finite(df_beta$beta) & is.finite(df_beta$beta_se) & df_beta$beta_se > 0, ]
  maf  <- snp_MAF(G, ind.col = df_beta$`_NUM_ID_`)
  keep <- maf > (1 / sqrt(nrow(G)))
  df_beta <- df_beta[keep, ]; maf <- maf[keep]
  sd_val <- sqrt(2 * maf * (1 - maf))
  sd_y   <- as.numeric(quantile(with(df_beta, sqrt(0.5*(n_eff*beta_se^2+beta^2))), 0.01, na.rm=TRUE))
  sd_ss  <- with(df_beta, sd_y / sqrt(n_eff * beta_se^2 + beta^2))
  is_bad <- sd_ss < (0.5*sd_val) | sd_ss > (sd_val+0.1) | sd_ss < 0.05 | sd_val < 0.05
  df_beta <- df_beta[!is_bad, ]
  chi2    <- (df_beta$beta / df_beta$beta_se)^2
  df_beta <- df_beta[is.finite(chi2) & chi2 > 0, ]
  cat(sprintf('After QC: %d SNPs\n', nrow(df_beta)))
  saveRDS(df_beta, local_ckpt)
}

# ── Step 3: Per-chromosome LD with RDS checkpointing ─────────────────────────
cat(sprintf('Per-chromosome LD (size=%d) — %s\n', SIZE, Sys.time()))
ld_all <- numeric(0); used_idx <- integer(0)

for (chr in 1:22) {
  ind_chr <- which(df_beta$chr == chr)
  if (length(ind_chr) == 0) next
  chr_rds <- file.path(CHR_DIR, sprintf('chr%02d.rds', chr))
  chr_ld  <- file.path(CHR_DIR, sprintf('chr%02d_ld.rds', chr))

  if (file.exists(chr_rds) && file.exists(chr_ld)) {
    cat(sprintf('  Chr %02d: %d SNPs [cached]\n', chr, length(ind_chr)))
    ld_all <- c(ld_all, readRDS(chr_ld)); used_idx <- c(used_idx, ind_chr); next
  }

  ind_col <- df_beta$`_NUM_ID_`[ind_chr]
  cat(sprintf('  Chr %02d: %d SNPs  start=%s\n', chr, length(ind_chr),
              format(Sys.time(), '%H:%M:%S')))
  corr0  <- snp_cor(G, ind.col = ind_col, size = SIZE, ncores = NCORES)
  ld_chr <- Matrix::colSums(corr0^2)
  saveRDS(corr0, chr_rds, compress = FALSE)
  saveRDS(ld_chr, chr_ld)
  cat(sprintf('  Chr %02d done  end=%s\n', chr, format(Sys.time(), '%H:%M:%S')))
  ld_all <- c(ld_all, ld_chr); used_idx <- c(used_idx, ind_chr)
  rm(corr0); gc()
}

df_beta <- df_beta[used_idx, ]
cat(sprintf('All LD done: %d variants — %s\n', nrow(df_beta), Sys.time()))

# ── Step 4: Build SFBM from chr RDS files (rebuilt every run — fast, ~minutes) ─
corr_pfx <- file.path(OUTDIR, 'corr')
if (file.exists(paste0(corr_pfx, '.sbk'))) unlink(paste0(corr_pfx, '.sbk'))
cat(sprintf('Building SFBM — %s\n', Sys.time()))
first <- TRUE; corr <- NULL
for (chr in 1:22) {
  chr_rds <- file.path(CHR_DIR, sprintf('chr%02d.rds', chr))
  if (!file.exists(chr_rds) || length(which(df_beta$chr == chr)) == 0) next
  corr0 <- readRDS(chr_rds)
  if (first) { corr <- as_SFBM(corr0, corr_pfx, compact = TRUE); first <- FALSE }
  else         corr$add_columns(corr0, nrow(corr))
  rm(corr0); gc()
}
cat(sprintf('SFBM built: %d variants — %s\n', nrow(corr), Sys.time()))

# ── Step 5: LDSC h² ──────────────────────────────────────────────────────────
ckpt_h2 <- file.path(OUTDIR, 'ckpt_h2.rds')
if (file.exists(ckpt_h2)) {
  h2 <- readRDS(ckpt_h2)
} else {
  ldsc <- tryCatch(
    with(df_beta, snp_ldsc(ld_all, length(ld_all), chi2 = (beta/beta_se)^2,
                            sample_size = n_eff, blocks = NULL)),
    error = function(e) list(h2 = NA))
  h2 <- ldsc[['h2']]
  if (is.na(h2) || h2 <= 0 || h2 > 1.5) h2 <- 0.05
  saveRDS(h2, ckpt_h2)
}
cat(sprintf('h2_init: %.4f\n', h2))

# ── Step 6: LDpred2-auto ─────────────────────────────────────────────────────
auto_file <- file.path(OUTDIR, 'auto.sscore')
if (!file.exists(auto_file)) {
  cat(sprintf('[LDpred2-auto] Running — %s\n', Sys.time()))
  multi_auto <- snp_ldpred2_auto(corr, df_beta, h2_init = h2,
                                  vec_p_init = seq_log(1e-4, 0.2, 30), ncores = NCORES)
  h2_vec <- sapply(multi_auto, function(a) {
    v <- tryCatch(a$h2_est, error = function(e) NA_real_)
    if (is.null(v) || length(v) == 0) NA_real_ else as.numeric(v)[1]
  })
  valid  <- is.finite(h2_vec)
  if (any(valid)) {
    h2_med <- median(h2_vec[valid])
    h2_mad <- max(mad(h2_vec[valid]), 1e-6)
    keep   <- valid & (abs(h2_vec - h2_med) < 3 * h2_mad)
  } else {
    keep <- rep(TRUE, length(multi_auto))
  }
  if (!any(keep)) keep <- valid
  if (!any(keep)) keep <- rep(TRUE, length(multi_auto))
  beta_auto <- sapply(multi_auto[keep], function(a) a$beta_est)
  beta_avg  <- if (is.matrix(beta_auto)) rowMeans(beta_auto) else beta_auto
  scores_auto <- big_prodVec(G, beta_avg, ind.col = df_beta$`_NUM_ID_`, ncores = NCORES)
  fam <- obj$fam
  fwrite(data.table(FID=fam$family.ID, IID=fam$sample.ID, PRS_auto=scores_auto),
         auto_file, sep = '\t')
  h2_kept <- mean(h2_vec[keep], na.rm = TRUE)
  p_kept  <- mean(sapply(multi_auto[keep], function(a) {
    v <- tryCatch(a$p_est, error = function(e) NA_real_)
    if (is.null(v) || length(v) == 0) NA_real_ else as.numeric(v)[1]
  }), na.rm = TRUE)
  saveRDS(list(h2 = h2_kept, p = p_kept, n_chains_kept = sum(keep)),
          file.path(OUTDIR, 'auto_params.rds'))
  cat(sprintf('[LDpred2-auto] h2=%.4f p=%.4f chains=%d/%d — %s\n',
    h2_kept, p_kept, sum(keep), length(multi_auto), Sys.time()))
} else { cat('[LDpred2-auto] Score file exists — skipping\n') }

# ── Step 7: Grid configs ──────────────────────────────────────────────────────
run_config <- function(label, params, score_file) {
  if (file.exists(score_file)) {
    cat(sprintf('[%s] Score file exists — skipping\n', label)); return(invisible(NULL))
  }
  cat(sprintf('[%s] Running %d models — %s\n', label, nrow(params), Sys.time()))
  beta_grid <- snp_ldpred2_grid(corr, df_beta, params, ncores = NCORES)
  scores    <- big_prodMat(G, beta_grid, ind.col = df_beta$`_NUM_ID_`, ncores = NCORES)
  fam       <- obj$fam
  dt        <- data.table(FID = fam$family.ID, IID = fam$sample.ID)
  for (j in seq_len(ncol(scores))) dt[[paste0('PRS_', j)]] <- scores[, j]
  fwrite(dt, score_file, sep = '\t')
  fwrite(as.data.table(params), sub('\\.sscore$', '_params.tsv', score_file), sep = '\t')
  cat(sprintf('[%s] Done — %s\n', label, Sys.time()))
}

p1 <- c(1e-4, 1e-3, 1e-2, 0.1)
h2_1 <- h2 * c(0.7, 1.0, 1.3)
run_config('Config1', expand.grid(p=p1, h2=h2_1, sparse=FALSE),
           file.path(OUTDIR, 'config1.sscore'))
run_config('Config2', expand.grid(p=p1, h2=h2_1, sparse=c(FALSE,TRUE)),
           file.path(OUTDIR, 'config2.sscore'))

p3 <- c(1e-5, 5e-5, 1e-4, 5e-4, 1e-3, 5e-3, 1e-2, 0.05, 0.1, 0.2, 0.5)
h2_3 <- h2 * c(0.5, 0.7, 1.0, 1.3, 1.5)
run_config('Config3', expand.grid(p=p3, h2=h2_3, sparse=c(FALSE,TRUE)),
           file.path(OUTDIR, 'config3.sscore'))

p4 <- c(1e-6, 5e-6, 1e-5, 5e-5, 1e-4)
h2_4 <- h2 * c(0.3, 0.5, 0.7, 1.0, 1.3)
run_config('Config4', expand.grid(p=p4, h2=h2_4, sparse=TRUE),
           file.path(OUTDIR, 'config4.sscore'))

cat(sprintf('=== Complete: PHENO=%s SIZE=%d — %s ===\n', PHENO, SIZE, Sys.time()))
