#!/bin/bash
#SBATCH --job-name=wc_alb_3k
#SBATCH --account=def-mdownie
#SBATCH --time=24:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=100G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/wc_alb_3k_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/wc_alb_3k_%j.err

module load r/4.5.0
echo "Start: $(date)"
Rscript /lustre09/project/6076774/mbhnzi/prs_ssns_final/cv_scripts/ldpred2_window_compare.R ALB 3000
echo "End: $(date)"
