#!/usr/bin/env Rscript
# Re-evaluate Simple PRS and C+T with 10 PCs and 20 PCs side by side
# OR, CI, P from ONE aggregate regression on concatenated out-of-fold predictions
# AUC (PRS only) from concatenated out-of-fold scores (no PCs)
# 5-fold CV, 4-way ancestry stratification, SEED=42
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({ library(data.table); library(pROC) })

BASE    <- '/lustre09/project/6076774/mbhnzi'
PHENO   <- file.path(BASE, 'archive/agent1/multi_ancestry/pheno_combined.txt')
PCA20   <- file.path(BASE, 'final_results/prs_v3/pca/pca_v3_20pc.eigenvec')
EUR_IDS <- file.path(BASE, 'rebuild_v3/tmp/eur_ordered.txt')
SL_IDS  <- file.path(BASE, 'rebuild_v3/tmp/sl_keep_ordered.txt')
N_FOLDS <- 5L
SEED    <- 42L

pheno <- fread(PHENO); setnames(pheno, c('FID', 'IID', 'SSNS'))
pca20 <- fread(PCA20); setnames(pca20, c('FID', 'IID', paste0('PC', 1:20)))

dat <- merge(pheno[!is.na(SSNS)], pca20, by = c('FID', 'IID'))
cat(sprintf('Samples: %d | Cases: %d | Controls: %d\n',
            nrow(dat), sum(dat$SSNS == 1), sum(dat$SSNS == 0)))

eur_ids <- fread(EUR_IDS, header = FALSE)$V1
sl_ids  <- fread(SL_IDS, header = TRUE)$IID
dat[, ancestry := ifelse(IID %in% eur_ids, 'EUR', 'SL')]
dat[, stratum  := paste0(ancestry, '_', ifelse(SSNS == 1, 'case', 'ctrl'))]

set.seed(SEED)
dat[, fold := NA_integer_]
for (s in unique(dat$stratum)) {
  idx <- which(dat$stratum == s)
  dat$fold[idx] <- sample(rep(1:N_FOLDS, length.out = length(idx)))
}
cat(sprintf('Fold sizes: %s\n', paste(table(dat$fold), collapse = ' ')))

# Aggregate: single regression on all concatenated out-of-fold predictions
agg_eval <- function(score_vec, y_vec, pc_df, label='') {
  ok <- is.finite(score_vec) & !is.na(y_vec)
  auc_prs <- suppressMessages(as.numeric(roc(y_vec[ok], score_vec[ok])$auc))
  df10 <- data.frame(y=y_vec[ok], prs=scale(score_vec[ok])[,1], pc_df[ok, 1:10, drop=FALSE])
  df20 <- data.frame(y=y_vec[ok], prs=scale(score_vec[ok])[,1], pc_df[ok, 1:20, drop=FALSE])
  fit10 <- glm(y ~ ., data=df10, family=binomial())
  fit20 <- glm(y ~ ., data=df20, family=binomial())
  extract <- function(fit) {
    co <- unname(coef(summary(fit))['prs',])
    list(or=exp(co[1]), ci_lo=exp(co[1]-1.96*co[2]), ci_hi=exp(co[1]+1.96*co[2]), p=co[4])
  }
  r10 <- extract(fit10); r20 <- extract(fit20)
  list(auc_prs=auc_prs, r10=r10, r20=r20)
}

cv_eval <- function(analysis, method, score_dt, score_cols, verbose=FALSE) {
  merged <- merge(dat, score_dt, by = c('FID', 'IID'))
  pc_cols <- paste0('PC', 1:20)

  oof_score <- numeric(nrow(merged))
  oof_y     <- integer(nrow(merged))
  oof_pc    <- as.data.frame(merged[, ..pc_cols])

  fold_or  <- numeric(N_FOLDS)
  fold_p   <- numeric(N_FOLDS)
  fold_auc <- numeric(N_FOLDS)
  best_cols_used <- character(N_FOLDS)

  for (k in seq_len(N_FOLDS)) {
    tr_idx  <- which(merged$fold != k)
    te_idx  <- which(merged$fold == k)
    train   <- merged[tr_idx]
    test    <- merged[te_idx]

    # Select best column on training by PRS-only AUC
    train_aucs <- sapply(score_cols, function(sc) {
      v <- train[[sc]]
      if (is.null(v) || !any(is.finite(v))) return(0.5)
      tryCatch(suppressMessages(as.numeric(roc(as.integer(train$SSNS), v)$auc)),
               error=function(e) 0.5)
    })
    best_col <- score_cols[which.max(train_aucs)]
    best_cols_used[k] <- best_col

    oof_score[te_idx] <- as.numeric(test[[best_col]])
    oof_y[te_idx]     <- as.integer(test$SSNS)

    # Per-fold diagnostics (10 PCs)
    ok <- is.finite(oof_score[te_idx]) & !is.na(oof_y[te_idx])
    sc_k <- oof_score[te_idx][ok]; y_k <- oof_y[te_idx][ok]
    fold_auc[k] <- suppressMessages(as.numeric(roc(y_k, sc_k)$auc))
    pc10_k <- oof_pc[te_idx[ok], 1:10, drop=FALSE]
    df_k <- data.frame(y=y_k, prs=scale(sc_k)[,1], pc10_k)
    m_k  <- tryCatch(glm(y ~ ., data=df_k, family=binomial()), error=function(e) NULL)
    if (!is.null(m_k)) {
      co_k <- unname(coef(summary(m_k))['prs',])
      fold_or[k] <- round(exp(co_k[1]), 3)
      fold_p[k]  <- signif(co_k[4], 3)
    } else { fold_or[k] <- NA; fold_p[k] <- NA }
  }

  cat(sprintf('\n[%s %s]\n', analysis, method))
  cat(sprintf('  Best col per fold: %s\n', paste(best_cols_used, collapse=' | ')))
  cat(sprintf('  Per-fold AUC_prs:  %s\n', paste(round(fold_auc, 3), collapse=' ')))
  cat(sprintf('  Per-fold OR (10pc):%s\n', paste(fold_or, collapse=' ')))
  cat(sprintf('  Per-fold P  (10pc):%s\n', paste(fold_p,  collapse=' ')))

  # Aggregate regression on all concatenated OOF predictions
  r <- agg_eval(oof_score, oof_y, oof_pc)

  cat(sprintf('  Aggregate AUC_prs=%.3f | OR_10=%s p_10=%s CI_10=[%s] | OR_20=%s p_20=%s CI_20=[%s]\n',
    r$auc_prs,
    round(r$r10$or,3), signif(r$r10$p,3),
    sprintf('%.3f-%.3f', r$r10$ci_lo, r$r10$ci_hi),
    round(r$r20$or,3), signif(r$r20$p,3),
    sprintf('%.3f-%.3f', r$r20$ci_lo, r$r20$ci_hi)))

  list(
    Analysis = analysis, Method = method,
    Best_col = names(which.max(table(best_cols_used))),
    AUC_prs  = round(r$auc_prs, 3),
    OR_10pc  = round(r$r10$or, 3),
    CI_10pc  = sprintf('%.3f-%.3f', r$r10$ci_lo, r$r10$ci_hi),
    P_10pc   = signif(r$r10$p, 3),
    OR_20pc  = round(r$r20$or, 3),
    CI_20pc  = sprintf('%.3f-%.3f', r$r20$ci_lo, r$r20$ci_hi),
    P_20pc   = signif(r$r20$p, 3)
  )
}

load_score <- function(f) {
  s <- fread(f)
  if ('#FID' %in% names(s)) setnames(s, '#FID', 'FID')
  s
}

results <- list()

# ── SSNS Simple PRS ───────────────────────────────────────────────────────────
f  <- file.path(BASE, 'prs_ssns_final/results/cv_filtered/simple_prs/simple_prs.sscore')
s  <- load_score(f)
sc <- grep('AVG$|^SCORE', names(s), value=TRUE)[1]
dt <- s[, .(FID, IID, PRS_1 = get(sc))]
results[[1]] <- cv_eval('SSNS', 'Simple PRS', dt, 'PRS_1')

# ── SSNS C+T ──────────────────────────────────────────────────────────────────
ct_dir   <- file.path(BASE, 'prs_ssns_final/results/cv_filtered/ct_prs')
ct_files <- list.files(ct_dir, pattern='\\.sscore$', full.names=TRUE)
ct_dt    <- NULL; ct_cols <- c()
for (f in ct_files) {
  s   <- load_score(f); sc <- grep('AVG$|^SCORE', names(s), value=TRUE)[1]
  lbl <- paste0('PRS_', sub('\\.sscore$', '', basename(f)))
  s_tmp <- s[, .(FID, IID)]; s_tmp[[lbl]] <- s[[sc]]
  ct_dt <- if (is.null(ct_dt)) s_tmp else merge(ct_dt, s_tmp, by=c('FID','IID'))
  ct_cols <- c(ct_cols, lbl)
}
results[[2]] <- cv_eval('SSNS', 'C+T', ct_dt, ct_cols)

# ── ALB Simple PRS ────────────────────────────────────────────────────────────
f  <- file.path(BASE, 'prs_alb_final/results/cv_filtered/simple_prs/simple_prs.sscore')
s  <- load_score(f); sc <- grep('AVG$|^SCORE', names(s), value=TRUE)[1]
dt <- s[, .(FID, IID, PRS_1 = get(sc))]
results[[3]] <- cv_eval('ALB', 'Simple PRS', dt, 'PRS_1')

# ── ALB C+T ───────────────────────────────────────────────────────────────────
ct_dir   <- file.path(BASE, 'prs_alb_final/results/cv_filtered/ct_prs')
ct_files <- list.files(ct_dir, pattern='\\.sscore$', full.names=TRUE)
ct_dt    <- NULL; ct_cols <- c()
for (f in ct_files) {
  s   <- load_score(f); sc <- grep('AVG$|^SCORE', names(s), value=TRUE)[1]
  lbl <- paste0('PRS_', sub('\\.sscore$', '', basename(f)))
  s_tmp <- s[, .(FID, IID)]; s_tmp[[lbl]] <- s[[sc]]
  ct_dt <- if (is.null(ct_dt)) s_tmp else merge(ct_dt, s_tmp, by=c('FID','IID'))
  ct_cols <- c(ct_cols, lbl)
}
results[[4]] <- cv_eval('ALB', 'C+T', ct_dt, ct_cols)

# ── Final table ───────────────────────────────────────────────────────────────
tbl <- rbindlist(lapply(results, as.data.table))
cat('\n')
cat(paste(rep('=', 120), collapse=''), '\n')
cat('FINAL TABLE — aggregate OOF regression (all metrics from same model)\n')
cat(paste(rep('=', 120), collapse=''), '\n')
cat(sprintf('%-6s %-12s %-18s %-7s | %-6s %-11s %-16s | %-6s %-11s %-16s\n',
  'Anal', 'Method', 'Best_col', 'AUC_prs',
  'OR_10', 'P_10', 'CI_10', 'OR_20', 'P_20', 'CI_20'))
cat(paste(rep('-', 120), collapse=''), '\n')
for (i in seq_len(nrow(tbl))) {
  r <- tbl[i]
  cat(sprintf('%-6s %-12s %-18s %-7s | %-6s %-11s %-16s | %-6s %-11s %-16s\n',
    r$Analysis, r$Method, r$Best_col, r$AUC_prs,
    r$OR_10pc, r$P_10pc, r$CI_10pc, r$OR_20pc, r$P_20pc, r$CI_20pc))
}
cat(paste(rep('=', 120), collapse=''), '\n')

fwrite(tbl, file.path(BASE, 'prs_ssns_final/results/window_comparison/simple_ct_20pc_results.tsv'), sep='\t')
cat('Saved: simple_ct_20pc_results.tsv\n')
cat(sprintf('=== Done — %s ===\n', Sys.time()))
