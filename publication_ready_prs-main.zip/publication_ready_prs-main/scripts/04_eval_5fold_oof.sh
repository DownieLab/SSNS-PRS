#!/bin/bash
#SBATCH --job-name=cv_simple_ct
#SBATCH --account=def-mdownie
#SBATCH --time=03:00:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/cv_simple_ct_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/cv_simple_ct_%j.err

set -euo pipefail

BED=/lustre09/project/6076774/mbhnzi/prs_ssns_final/data/combined_eur_sl_filtered
GWAS=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/barry_hm3_qc.ma
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/cv_filtered
THREADS=$SLURM_CPUS_PER_TASK

mkdir -p $OUTDIR/simple_prs $OUTDIR/ct_prs
echo "Start: $(date)"

# ── Simple PRS ───────────────────────────────────────────────────────────────
module load plink/2.00-20231024-avx2

if [ ! -f $OUTDIR/simple_prs/simple_prs.sscore ]; then
  echo "Running Simple PRS..."
  plink2 --bfile $BED \
         --score $GWAS 1 2 5 header-read \
         --out $OUTDIR/simple_prs/simple_prs \
         --threads $THREADS --memory 28000
  echo "Simple PRS done: $(date)"
else
  echo "Simple PRS score file exists — skipping"
fi

# ── Clumping ─────────────────────────────────────────────────────────────────
module purge
module load plink/2.00a5.8

CT_DIR=$OUTDIR/ct_prs

if [ ! -f $CT_DIR/clumped_snps.txt ]; then
  echo "Clumping..."
  awk 'BEGIN{OFS="\t"} NR==1 {print "SNP","P"} NR>1 {print $1, $7}' $GWAS \
      > $CT_DIR/gwas_for_clump.txt

  plink2 --bfile $BED \
         --clump $CT_DIR/gwas_for_clump.txt \
         --clump-r2 0.1 --clump-kb 250 --clump-p1 1.0 \
         --out $CT_DIR/clumped \
         --threads $THREADS --memory 28000

  awk 'NR>1 && $3!="" {print $3}' $CT_DIR/clumped.clumps > $CT_DIR/clumped_snps.txt
  NCLUMP=$(wc -l < $CT_DIR/clumped_snps.txt)
  echo "Clumped SNPs: $NCLUMP"
else
  echo "Clumped SNPs file exists — skipping clumping"
fi

# ── C+T scoring at each threshold ────────────────────────────────────────────
module purge
module load plink/2.00-20231024-avx2

THRESHOLDS="5e-8 1e-6 1e-5 1e-4 5e-4 0.001 0.01 0.05 0.1 0.5 1.0"

for THRESH in $THRESHOLDS; do
  LABEL=$(echo $THRESH | sed 's/\./_/g; s/-/m/g')
  if [ -f $CT_DIR/ct_${LABEL}.sscore ]; then
    echo "  $THRESH: score file exists — skipping"
    continue
  fi

  awk -v t=$THRESH 'BEGIN{OFS="\t"}
      NR==FNR { snps[$1]=1; next }
      FNR==1  { print; next }
      ($1 in snps) && ($7+0 <= t+0) { print }
  ' $CT_DIR/clumped_snps.txt $GWAS > $CT_DIR/ct_thresh_${LABEL}.ma

  NSNP=$(awk 'NR>1' $CT_DIR/ct_thresh_${LABEL}.ma | wc -l)
  echo "  Threshold $THRESH: $NSNP SNPs"

  if [ "$NSNP" -gt 0 ]; then
    plink2 --bfile $BED \
           --score $CT_DIR/ct_thresh_${LABEL}.ma 1 2 5 header-read \
           --out $CT_DIR/ct_${LABEL} \
           --threads $THREADS --memory 28000
  fi
done

echo "End: $(date)"
echo "=== Simple PRS + C+T Done ==="
