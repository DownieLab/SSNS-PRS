#!/bin/bash
#SBATCH --job-name=hla_excl
#SBATCH --account=def-mdownie
#SBATCH --time=6:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=100G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/hla_excl_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/hla_excl_%j.err

module load r/4.5.0 plink/2.0.0-a.6.32
echo "=== HLA exclusion job start: $(date) ==="

BED=/lustre09/project/6076774/mbhnzi/prs_ssns_final/data/combined_eur_sl_filtered
ALB_MA=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/alb_hm3_qc.ma
CT_MA=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/cv_filtered/ct_prs/ct_thresh_0_001.ma
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/window_comparison/hla_test
LOGS=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs

mkdir -p $OUTDIR $LOGS

# ── Build HLA SNP list from BIM (chr6:25,000,000–34,000,000) ─────────────────
echo "Building HLA exclusion list (chr6:25-34Mb)..."
awk '$1==6 && $4>=25000000 && $4<=34000000 {print $2}' ${BED}.bim > $OUTDIR/hla_snps_bim.txt
echo "HLA SNPs in genotype data (BIM): $(wc -l < $OUTDIR/hla_snps_bim.txt)"

# ── PLINK: Simple PRS HLA-only contribution ───────────────────────────────────
echo "Scoring Simple PRS HLA-only..."
plink2 --bfile $BED \
  --score $ALB_MA 1 2 5 header-read \
  --extract $OUTDIR/hla_snps_bim.txt \
  --out $OUTDIR/simple_hla_only \
  --threads 1 --memory 40000
echo "Simple HLA-only SNPs used: $(awk 'NR>1{print $3/2; exit}' $OUTDIR/simple_hla_only.sscore)"

# ── PLINK: C+T ct_0_001 HLA-only contribution ────────────────────────────────
echo "Scoring C+T ct_0_001 HLA-only..."
plink2 --bfile $BED \
  --score $CT_MA 1 2 5 header-read \
  --extract $OUTDIR/hla_snps_bim.txt \
  --out $OUTDIR/ct_0_001_hla_only \
  --threads 1 --memory 40000
echo "C+T HLA-only SNPs used: $(awk 'NR>1{print $3/2; exit}' $OUTDIR/ct_0_001_hla_only.sscore)"

# ── R: LDpred2 noHLA + all evaluation ────────────────────────────────────────
echo "Starting R evaluation: $(date)"
Rscript /lustre09/project/6076774/mbhnzi/prs_ssns_final/cv_scripts/hla_exclusion_eval.R

echo "=== Done: $(date) ==="
