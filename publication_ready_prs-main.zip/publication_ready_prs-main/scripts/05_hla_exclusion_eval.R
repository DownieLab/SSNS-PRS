#!/usr/bin/env Rscript
# HLA exclusion analysis — ALB PRS evaluated on SSNS phenotype
# Simple PRS: full_score - hla_only_score (PLINK outputs in OUTDIR)
# C+T (ct_0_001): same subtraction approach
# LDpred2 Config1 size=3000: rebuild SFBM with chr6 subsetted (HLA removed), re-run grid
# Evaluate with: (1) 5-fold CV aggregate OOF, (2) 70/30 train/test split
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({
  library(bigsnpr); library(bigsparser); library(data.table); library(pROC)
})

BASE    <- '/lustre09/project/6076774/mbhnzi'
BED     <- file.path(BASE, 'prs_ssns_final/data/combined_eur_sl_filtered')
ALB_DIR <- file.path(BASE, 'prs_ssns_final/results/window_comparison/alb_size3000')
CHR_DIR <- file.path(ALB_DIR, 'chr_corr')
OUTDIR  <- file.path(BASE, 'prs_ssns_final/results/window_comparison/hla_test')
PHENO   <- file.path(BASE, 'archive/agent1/multi_ancestry/pheno_combined.txt')
PCA20   <- file.path(BASE, 'final_results/prs_v3/pca/pca_v3_20pc.eigenvec')
EUR_IDS <- file.path(BASE, 'rebuild_v3/tmp/eur_ordered.txt')
SL_IDS  <- file.path(BASE, 'rebuild_v3/tmp/sl_keep_ordered.txt')
N_FOLDS <- 5L; SEED <- 42L; NCORES <- 1L

dir.create(OUTDIR, recursive=TRUE, showWarnings=FALSE)
cat(sprintf('=== HLA exclusion analysis — %s ===\n', Sys.time()))

# ── Load phenotype, PCA, fold assignments ─────────────────────────────────────
pheno <- fread(PHENO); setnames(pheno, c('FID','IID','SSNS'))
pca20 <- fread(PCA20); setnames(pca20, c('FID','IID',paste0('PC',1:20)))
dat   <- merge(pheno[!is.na(SSNS)], pca20, by=c('FID','IID'))
cat(sprintf('Samples: N=%d, cases=%d, controls=%d\n',
            nrow(dat), sum(dat$SSNS==1), sum(dat$SSNS==0)))

eur_ids <- fread(EUR_IDS, header=FALSE)$V1
sl_ids  <- fread(SL_IDS, header=TRUE)$IID
dat[, ancestry := ifelse(IID %in% eur_ids, 'EUR', 'SL')]
dat[, stratum  := paste0(ancestry,'_',ifelse(SSNS==1,'case','ctrl'))]

# 5-fold assignments
set.seed(SEED)
dat[, fold := NA_integer_]
for (s in unique(dat$stratum)) {
  idx <- which(dat$stratum == s)
  dat$fold[idx] <- sample(rep(1:N_FOLDS, length.out=length(idx)))
}

# 70/30 split
set.seed(SEED)
dat[, train7030 := NA]
for (grp in c(0L,1L)) {
  idx <- which(dat$SSNS == grp)
  sel <- sample(idx, round(0.7*length(idx)))
  dat$train7030[sel] <- TRUE
  dat$train7030[setdiff(idx,sel)] <- FALSE
}
train70 <- dat[train7030==TRUE]
test30  <- dat[train7030==FALSE]
cat(sprintf('Train: N=%d, cases=%d | Test: N=%d, cases=%d\n',
            nrow(train70), sum(train70$SSNS==1), nrow(test30), sum(test30$SSNS==1)))

# ── Evaluation helpers ─────────────────────────────────────────────────────────
pc20_cols <- paste0('PC',1:20)

eval_reg <- function(sc, y, pc_df) {
  ok <- is.finite(sc) & !is.na(y)
  if (sum(ok)<10 || length(unique(y[ok]))<2)
    return(list(auc_prs=NA, auc_adj=NA, or=NA, ci_lo=NA, ci_hi=NA, p=NA))
  auc_prs <- suppressMessages(as.numeric(roc(y[ok], sc[ok])$auc))
  df <- data.frame(y=y[ok], prs=scale(sc[ok])[,1], pc_df[ok,,drop=FALSE])
  m  <- glm(y~., data=df, family=binomial())
  auc_adj <- suppressMessages(as.numeric(roc(y[ok], fitted(m))$auc))
  co <- unname(coef(summary(m))['prs',])
  list(auc_prs=auc_prs, auc_adj=auc_adj,
       or=exp(co[1]), ci_lo=exp(co[1]-1.96*co[2]), ci_hi=exp(co[1]+1.96*co[2]), p=co[4])
}

# 5-fold CV aggregate OOF
cv_agg <- function(score_dt, score_col) {
  merged <- merge(dat, score_dt, by=c('FID','IID'))
  oof_sc <- numeric(nrow(merged)); oof_y <- integer(nrow(merged))
  for (k in seq_len(N_FOLDS)) {
    te <- which(merged$fold==k)
    oof_sc[te] <- as.numeric(merged[[score_col]][te])
    oof_y[te]  <- as.integer(merged$SSNS[te])
  }
  eval_reg(oof_sc, oof_y, as.data.frame(merged[, ..pc20_cols]))
}

# 70/30 test set
eval_7030 <- function(score_dt, score_col) {
  te <- merge(test30, score_dt, by=c('FID','IID'))
  eval_reg(as.numeric(te[[score_col]]), as.integer(te$SSNS),
           as.data.frame(te[, ..pc20_cols]))
}

# Best model selection on 70% training
best_on_train <- function(score_dt, score_cols) {
  tr <- merge(train70[,.(FID,IID,SSNS)], score_dt, by=c('FID','IID'))
  aucs <- sapply(score_cols, function(sc) {
    v <- tr[[sc]]; if (!any(is.finite(v))) return(0.5)
    suppressMessages(as.numeric(roc(as.integer(tr$SSNS),v)$auc))
  })
  score_cols[which.max(aucs)]
}

fmt <- function(r) {
  sprintf('OR=%.3f [%.3f-%.3f] p=%s AUC_prs=%.3f AUC_adj=%.3f',
          r$or, r$ci_lo, r$ci_hi, signif(r$p,3), r$auc_prs, r$auc_adj)
}

# ── Step 1: Load PLINK HLA-only scores and compute noHLA by subtraction ───────
cat('\n--- Computing Simple PRS and C+T no-HLA scores ---\n')

load_sscore <- function(f) {
  s <- fread(f); if ('#FID' %in% names(s)) setnames(s,'#FID','FID'); s
}

# Full scores (existing)
simple_full <- load_sscore(file.path(BASE,'prs_alb_final/results/cv_filtered/simple_prs/simple_prs.sscore'))
ct_full     <- load_sscore(file.path(BASE,'prs_alb_final/results/cv_filtered/ct_prs/ct_0_001.sscore'))

# HLA-only scores (computed by SLURM bash section with PLINK)
simple_hla  <- load_sscore(file.path(OUTDIR,'simple_hla_only.sscore'))
ct_hla      <- load_sscore(file.path(OUTDIR,'ct_0_001_hla_only.sscore'))

# Number of HLA SNPs per method
simple_hla_nsnp <- simple_hla$ALLELE_CT[1] / 2  # ALLELE_CT = 2 * N_SNPs used
ct_hla_nsnp     <- ct_hla$ALLELE_CT[1] / 2
cat(sprintf('Simple PRS: %d HLA SNPs in scoring file\n', as.integer(simple_hla_nsnp)))
cat(sprintf('C+T ct_0_001: %d HLA SNPs in scoring file\n', as.integer(ct_hla_nsnp)))

# noHLA = raw_full - raw_hla  (raw = b_AVG * ALLELE_CT)
compute_noHLA <- function(full, hla) {
  m <- merge(full[,.(FID,IID,raw_full=b_AVG*ALLELE_CT)],
             hla[, .(FID,IID,raw_hla =b_AVG*ALLELE_CT)], by=c('FID','IID'))
  m[, .(FID, IID, PRS_noHLA = raw_full - raw_hla)]
}
simple_noHLA_dt <- compute_noHLA(simple_full, simple_hla)
ct_noHLA_dt     <- compute_noHLA(ct_full,     ct_hla)

# ── Step 2: LDpred2 Config1 no-HLA ────────────────────────────────────────────
cat(sprintf('\n--- LDpred2 Config1 no-HLA — %s ---\n', Sys.time()))
obj <- snp_attach(paste0(BED,'.rds'))
G   <- obj$genotypes

df_beta <- readRDS(file.path(ALB_DIR,'ckpt_df_beta_qc.rds'))
cat(sprintf('df_beta total: %d SNPs\n', nrow(df_beta)))

# HLA indices
hla_mask <- df_beta$chr==6 & df_beta$pos>=25e6 & df_beta$pos<=34e6
cat(sprintf('HLA SNPs in df_beta (chr6:25-34Mb): %d\n', sum(hla_mask)))
df_beta_noHLA <- df_beta[!hla_mask, ]
cat(sprintf('df_beta after HLA removal: %d SNPs\n', nrow(df_beta_noHLA)))

# Rebuild SFBM with chr6 subsetted
corr_pfx <- file.path(OUTDIR,'corr_noHLA')
if (file.exists(paste0(corr_pfx,'.sbk'))) unlink(paste0(corr_pfx,'.sbk'))
cat(sprintf('Building noHLA SFBM — %s\n', Sys.time()))
first <- TRUE; corr <- NULL

for (chr in 1:22) {
  ind_chr <- which(df_beta$chr==chr)
  if (length(ind_chr)==0) next
  ind_chr_noHLA <- which(df_beta_noHLA$chr==chr)
  if (length(ind_chr_noHLA)==0) {
    cat(sprintf('  Chr %02d: all SNPs are HLA, skipping\n', chr)); next
  }
  chr_rds <- file.path(CHR_DIR, sprintf('chr%02d.rds',chr))
  corr0 <- readRDS(chr_rds)
  if (chr==6) {
    # find positions within chr6 block that are non-HLA
    hla_within <- which(df_beta$pos[ind_chr]>=25e6 & df_beta$pos[ind_chr]<=34e6)
    keep_within <- setdiff(seq_len(length(ind_chr)), hla_within)
    corr0 <- corr0[keep_within, keep_within, drop=FALSE]
    cat(sprintf('  Chr 06: %d->%d SNPs (removed %d HLA)\n',
                length(ind_chr), nrow(corr0), length(hla_within)))
  } else {
    cat(sprintf('  Chr %02d: %d SNPs [cached]\n', chr, length(ind_chr_noHLA)))
  }
  if (first) { corr <- as_SFBM(corr0, corr_pfx, compact=TRUE); first <- FALSE }
  else         corr$add_columns(corr0, nrow(corr))
  rm(corr0); gc()
}
cat(sprintf('SFBM built: %d variants — %s\n', nrow(corr), Sys.time()))

# Config1 params
h2 <- readRDS(file.path(ALB_DIR,'ckpt_h2.rds'))
params <- expand.grid(p=c(1e-4,1e-3,1e-2,0.1), h2=h2*c(0.7,1.0,1.3), sparse=FALSE)
cat(sprintf('[LDpred2 Config1 noHLA] %d models — %s\n', nrow(params), Sys.time()))
beta_grid  <- snp_ldpred2_grid(corr, df_beta_noHLA, params, ncores=NCORES)
scores_mat <- big_prodMat(G, beta_grid, ind.col=df_beta_noHLA$`_NUM_ID_`, ncores=NCORES)
cat(sprintf('[LDpred2 Config1 noHLA] Done — %s\n', Sys.time()))

fam <- obj$fam
ld_dt <- data.table(FID=fam$family.ID, IID=fam$sample.ID)
for (j in seq_len(ncol(scores_mat))) ld_dt[[paste0('PRS_',j)]] <- scores_mat[,j]
ld_cols <- paste0('PRS_', seq_len(ncol(scores_mat)))

# ── Step 3: Evaluate ──────────────────────────────────────────────────────────
cat('\n--- Evaluation ---\n')

# LDpred2 model selection on training
ld_best_col <- best_on_train(ld_dt, ld_cols)
ld_best_j   <- as.integer(sub('^PRS_','',ld_best_col))
cat(sprintf('LDpred2 noHLA best model on training: %s (p=%s h2=%.4f sparse=%s)\n',
            ld_best_col, params$p[ld_best_j], params$h2[ld_best_j], params$sparse[ld_best_j]))

# Also need LDpred2 WITH HLA (existing config1.sscore PRS_3 from 70/30 analysis)
ld_full_dt <- load_sscore(file.path(ALB_DIR,'config1.sscore'))
ld_full_cols <- grep('^PRS_', names(ld_full_dt), value=TRUE)
ld_full_best <- best_on_train(ld_full_dt, ld_full_cols)
cat(sprintf('LDpred2 WITH HLA best model on training: %s\n', ld_full_best))

# ── Collect results ───────────────────────────────────────────────────────────
results <- list()

for (method_info in list(
  list(name='Simple PRS',    incl=simple_full,   excl=simple_noHLA_dt,
       col_i='b_AVG',        col_e='PRS_noHLA',  nsnp_hla=as.integer(simple_hla_nsnp)),
  list(name='C+T (ct_0_001)', incl=ct_full,      excl=ct_noHLA_dt,
       col_i='b_AVG',        col_e='PRS_noHLA',  nsnp_hla=as.integer(ct_hla_nsnp)),
  list(name='LDpred2 Config1', incl=ld_full_dt,  excl=ld_dt,
       col_i=ld_full_best,   col_e=ld_best_col,  nsnp_hla=sum(hla_mask))
)) {
  cat(sprintf('\n[%s] HLA SNPs excluded: %d\n', method_info$name, method_info$nsnp_hla))

  r_incl_cv <- cv_agg(method_info$incl, method_info$col_i)
  r_excl_cv <- cv_agg(method_info$excl, method_info$col_e)

  r_incl_70 <- eval_7030(method_info$incl, method_info$col_i)
  r_excl_70 <- eval_7030(method_info$excl, method_info$col_e)

  cat(sprintf('  5-fold INCL: %s\n', fmt(r_incl_cv)))
  cat(sprintf('  5-fold EXCL: %s\n', fmt(r_excl_cv)))
  cat(sprintf('  70/30  INCL: %s\n', fmt(r_incl_70)))
  cat(sprintf('  70/30  EXCL: %s\n', fmt(r_excl_70)))

  results[[method_info$name]] <- data.table(
    Method=method_info$name, HLA_SNPs_excluded=method_info$nsnp_hla,
    # 5-fold
    OR_incl_cv=round(r_incl_cv$or,3), P_incl_cv=signif(r_incl_cv$p,3),
    CI_incl_cv=sprintf('%.3f-%.3f',r_incl_cv$ci_lo,r_incl_cv$ci_hi),
    OR_excl_cv=round(r_excl_cv$or,3), P_excl_cv=signif(r_excl_cv$p,3),
    CI_excl_cv=sprintf('%.3f-%.3f',r_excl_cv$ci_lo,r_excl_cv$ci_hi),
    # 70/30
    OR_incl_70=round(r_incl_70$or,3), P_incl_70=signif(r_incl_70$p,3),
    CI_incl_70=sprintf('%.3f-%.3f',r_incl_70$ci_lo,r_incl_70$ci_hi),
    OR_excl_70=round(r_excl_70$or,3), P_excl_70=signif(r_excl_70$p,3),
    CI_excl_70=sprintf('%.3f-%.3f',r_excl_70$ci_lo,r_excl_70$ci_hi)
  )
}

# ── Final table ───────────────────────────────────────────────────────────────
tbl <- rbindlist(results)
cat('\n\n')
cat(paste(rep('=',130),collapse=''),'\n')
cat('ALB PRS HLA EXCLUSION: chr6:25,000,000-34,000,000\n')
cat(paste(rep('=',130),collapse=''),'\n')

cat(sprintf('\n%-22s %8s | %-40s | %-40s\n',
  'Method','HLA_N','5-fold CV aggregate OOF','70/30 test set'))
cat(sprintf('%-22s %8s | %-18s %-10s %-14s | %-18s %-10s %-14s\n',
  '','',
  'OR_incl','P_incl','OR_excl P_excl',
  'OR_incl','P_incl','OR_excl P_excl'))
cat(paste(rep('-',130),collapse=''),'\n')

for (i in seq_len(nrow(tbl))) {
  r <- tbl[i]
  cat(sprintf('%-22s %8d | OR=%-5s p=%-10s | OR=%-5s p=%-10s || OR=%-5s p=%-10s | OR=%-5s p=%-10s\n',
    r$Method, r$HLA_SNPs_excluded,
    r$OR_incl_cv, r$P_incl_cv, r$OR_excl_cv, r$P_excl_cv,
    r$OR_incl_70, r$P_incl_70, r$OR_excl_70, r$P_excl_70))
  cat(sprintf('%-22s %8s | CI=[%-12s]  CI=[%-12s]    || CI=[%-12s]  CI=[%-12s]\n',
    '','',
    r$CI_incl_cv, r$CI_excl_cv, r$CI_incl_70, r$CI_excl_70))
}
cat(paste(rep('=',130),collapse=''),'\n')

fwrite(tbl, file.path(OUTDIR,'hla_exclusion_results.tsv'), sep='\t')
cat(sprintf('Saved: hla_exclusion_results.tsv\n'))
cat(sprintf('=== Done — %s ===\n', Sys.time()))
