#!/usr/bin/env Rscript
# Build alb_hm3_qc.ma using same rsID→chr:pos approach as make_locuszoom_alb.R
# Plus Teumer allele freq, HapMap3 QC, SD-concordance, MAF filter
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({library(bigsnpr); library(data.table)})

METAL_FILE <- '/lustre09/project/6076774/mbhnzi/final_results/meta_metal_results2_1.tbl'
TEU_FILE   <- '/lustre09/project/6076774/mbhnzi/data/teumer/teumer_for_metal.txt'
BRD_FILE   <- '/lustre09/project/6076774/mbhnzi/data/brandenburg/brandenburg_for_metal.txt'
TEU_FREQ   <- '/lustre09/project/6076774/mbhnzi/data/teumer/formatted_20180205-MA_overall-ALL-nstud_18-SumMac_400.tbl.rsid'
HM3_FILE   <- '/lustre09/project/6076774/mbhnzi/final_results/tmp-data/map_hm3.rds'
BED_PREFIX <- '/lustre09/project/6076774/mbhnzi/rebuild_v3/combined_eur_sl_v3_final'
OUTFILE    <- '/lustre09/project/6076774/mbhnzi/prs_alb_final/results/alb_hm3_qc.ma'
N_EFF      <- 347284L

dir.create(dirname(OUTFILE), recursive = TRUE, showWarnings = FALSE)
cat('=== Albuminuria .ma preparation ===\n\n')

# ── Exact same load_cohort as make_locuszoom_alb.R ────────────────────────────
cat('Step 1: Build rsID→chr:pos lookup from Teumer + Brandenburg\n')
valid_chrs <- as.character(1:22)

load_cohort <- function(path) {
  dt <- fread(path, sep = '\t',
              select = c('MarkerName', 'Chr', 'Position'),
              colClasses = list(character = c('MarkerName', 'Chr'), integer = 'Position'))
  setnames(dt, c('rsid', 'chr', 'pos'))
  dt[, rsid := gsub('"', '', rsid)]
  dt <- dt[grepl('^rs[0-9]+$', rsid) & chr %in% valid_chrs & !is.na(pos) & pos > 0]
  dt_dedup <- unique(dt, by = c('rsid', 'chr', 'pos'))
  incon <- dt_dedup[duplicated(rsid) | duplicated(rsid, fromLast = TRUE), unique(rsid)]
  unique(dt[!rsid %in% incon], by = 'rsid')
}

teu <- load_cohort(TEU_FILE)
cat(sprintf('  Teumer unique rsIDs: %d\n', nrow(teu)))
brd <- load_cohort(BRD_FILE)
cat(sprintf('  Brandenburg unique rsIDs: %d\n', nrow(brd)))

both     <- merge(teu, brd, by = 'rsid', suffixes = c('_t', '_b'))
conflict <- both[chr_t != chr_b | pos_t != pos_b, rsid]
cat(sprintf('  Conflicting rsIDs (dropped): %d\n', length(conflict)))
lookup   <- unique(rbind(teu[!rsid %in% conflict], brd[!rsid %in% conflict]), by = 'rsid')
lookup[, chr := as.integer(chr)]
cat(sprintf('  Lookup size: %d unique rsIDs\n', nrow(lookup)))

# ── Load METAL output ─────────────────────────────────────────────────────────
cat('\nStep 2: Load METAL file and join with lookup\n')
metal <- fread(METAL_FILE, sep = '\t')
setnames(metal, 'MarkerName', 'rsid')
cat(sprintf('  METAL rows: %d\n', nrow(metal)))

metal[, Allele1 := toupper(Allele1)]
metal[, Allele2 := toupper(Allele2)]
metal <- metal[!is.na(Effect) & !is.na(StdErr) & StdErr > 0 &
               !is.na(`P-value`) & `P-value` > 0 & `P-value` <= 1]

merged <- merge(metal, lookup[, .(rsid, chr, pos)], by = 'rsid', all.x = FALSE)
cat(sprintf('  After chr:pos join: %d SNPs\n', nrow(merged)))

# Build chr:pos SNP ID
merged[, SNP := paste0(chr, ':', pos)]

# Remove ambiguous strand SNPs (A/T, C/G)
merged <- merged[!((Allele1 == 'A' & Allele2 == 'T') | (Allele1 == 'T' & Allele2 == 'A') |
                   (Allele1 == 'C' & Allele2 == 'G') | (Allele1 == 'G' & Allele2 == 'C'))]
cat(sprintf('  After removing ambiguous SNPs: %d\n', nrow(merged)))

# Deduplicate by chr:pos (keep lowest p)
merged <- merged[order(`P-value`)][!duplicated(SNP)]
cat(sprintf('  After deduplication by chr:pos: %d\n', nrow(merged)))

# ── Allele frequency from Teumer ──────────────────────────────────────────────
cat('\nStep 3: Add allele frequency from Teumer (Freq1)\n')
# Columns: Chr Pos_b37 RSID Allele1 Allele2 Freq1 ...
teu_f <- fread(TEU_FREQ, select = c('RSID', 'Freq1'))
setnames(teu_f, c('rsid', 'freq'))
teu_f <- teu_f[grepl('^rs[0-9]+$', rsid) & !is.na(freq) & freq > 0 & freq < 1]
teu_f <- unique(teu_f, by = 'rsid')
cat(sprintf('  Teumer freq rows: %d\n', nrow(teu_f)))

merged <- merge(merged, teu_f, by = 'rsid', all.x = TRUE)
cat(sprintf('  SNPs with freq: %d | Missing: %d (will use 0.5)\n',
    sum(!is.na(merged$freq)), sum(is.na(merged$freq))))
merged[is.na(freq), freq := 0.5]

# ── HapMap3 matching ──────────────────────────────────────────────────────────
cat('\nStep 4: HapMap3 matching via snp_match\n')
hm3 <- readRDS(HM3_FILE)
cat(sprintf('  HM3 SNPs: %d\n', nrow(hm3)))

sumstats <- data.frame(
  chr     = as.integer(merged$chr),
  pos     = as.integer(merged$pos),
  a0      = merged$Allele2,   # non-effect allele
  a1      = merged$Allele1,   # effect allele
  beta    = merged$Effect,
  beta_se = merged$StdErr,
  p       = merged$`P-value`,
  n_eff   = N_EFF,
  freq    = merged$freq
)
map_hm3 <- data.frame(
  chr = as.integer(hm3$chr), pos = as.integer(hm3$pos),
  a0  = hm3$a0,              a1  = hm3$a1
)

df <- snp_match(sumstats, map_hm3, join_by_pos = TRUE)
df$SNP_ID <- paste0(df$chr, ':', df$pos)
cat(sprintf('  After HM3 match: %d SNPs\n', nrow(df)))

# ── QC filters ────────────────────────────────────────────────────────────────
cat('\nStep 5: QC filters\n')
n <- N_EFF

maf_thresh <- 1 / sqrt(n)
maf_val    <- pmin(df$freq, 1 - df$freq)
df <- df[!is.na(maf_val) & maf_val > maf_thresh, ]
cat(sprintf('  After MAF > %.4f: %d\n', maf_thresh, nrow(df)))

df$sd_val <- sqrt(2 * df$freq * (1 - df$freq))
df$sd_ss  <- with(df, 2 / sqrt(n * beta_se^2 + beta^2))
keep_sd   <- with(df, !(sd_ss < 0.5*sd_val | sd_ss > sd_val+0.1 | sd_ss < 0.05 | sd_val < 0.05))
df <- df[keep_sd, ]
cat(sprintf('  After SD-concordance: %d\n', nrow(df)))

chi2 <- (df$beta / df$beta_se)^2
df <- df[is.finite(chi2) & chi2 >= 0, ]
cat(sprintf('  After chi² filter: %d\n', nrow(df)))

# ── Save ──────────────────────────────────────────────────────────────────────
cat('\nStep 6: Save .ma file\n')
out <- data.table(
  SNP  = df$SNP_ID,
  A1   = toupper(df$a1),
  A2   = toupper(df$a0),
  freq = df$freq,
  b    = df$beta,
  se   = df$beta_se,
  p    = df$p,
  N    = N_EFF
)
fwrite(out, OUTFILE, sep = '\t')
cat(sprintf('Saved: %s\n', OUTFILE))
cat(sprintf('Final SNP count: %d\n', nrow(out)))
cat(sprintf('GWS hits (p < 5e-8): %d\n', sum(out$p < 5e-8)))
cat(sprintf('Chr15 SNPs: %d\n', sum(grepl('^15:', out$SNP))))

# Per-chromosome count
out[, chr_n := as.integer(sub(':.*', '', SNP))]
chr_tab <- out[, .N, by = chr_n][order(chr_n)]
cat('\nPer-chromosome:\n')
print(chr_tab)
cat('\n=== PREPARATION COMPLETE ===\n')
