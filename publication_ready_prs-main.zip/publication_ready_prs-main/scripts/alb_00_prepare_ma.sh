#!/bin/bash
#SBATCH --job-name=alb_prepare
#SBATCH --account=def-mdownie
#SBATCH --time=04:00:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=48G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/prepare_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/prepare_%j.err

module load r/4.5.0
Rscript /lustre09/project/6076774/mbhnzi/prs_alb_final/scripts/00_prepare_alb_ma.R
