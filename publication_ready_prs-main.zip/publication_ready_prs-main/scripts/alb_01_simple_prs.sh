#!/bin/bash
#SBATCH --job-name=alb_simple
#SBATCH --account=def-mdownie
#SBATCH --time=00:30:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=12G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/simple_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/simple_%j.err

set -euo pipefail
module load plink/2.00-20231024-avx2

MA_FILE=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/alb_hm3_qc.ma
BED=/lustre09/project/6076774/mbhnzi/rebuild_v3/combined_eur_sl_v3_final
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/simple_prs
mkdir -p "$OUTDIR"

echo "Start: $(date)"
plink2 \
  --bfile "$BED" \
  --score "$MA_FILE" 1 2 5 header-read \
  --memory 11000 \
  --out "$OUTDIR/simple"
echo "End: $(date)"
echo "=== Simple PRS done ==="
