#!/bin/bash
#SBATCH --job-name=alb_ct
#SBATCH --account=def-mdownie
#SBATCH --time=02:00:00
#SBATCH --cpus-per-task=1
#SBATCH --mem=18G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/ct_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/ct_%j.err

set -euo pipefail
MA_FILE=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/alb_hm3_qc.ma
BED=/lustre09/project/6076774/mbhnzi/rebuild_v3/combined_eur_sl_v3_final
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_alb_final/results/ct_prs
mkdir -p "$OUTDIR"

echo "Start: $(date)"

# Prepare clump input: SNP ID and P-value columns from .ma file
# .ma header: SNP A1 A2 freq b se p N
awk 'NR>1 {print $1, $7}' "$MA_FILE" > "$OUTDIR/gwas_for_clump.txt"
echo "SNP P" | cat - "$OUTDIR/gwas_for_clump.txt" > "$OUTDIR/gwas_for_clump_hdr.txt"
mv "$OUTDIR/gwas_for_clump_hdr.txt" "$OUTDIR/gwas_for_clump.txt"

# Clump with plink2 (avx2 for speed)
module load plink/2.00a5.8
plink2 \
  --bfile "$BED" \
  --clump "$OUTDIR/gwas_for_clump.txt" \
  --clump-p1 1.0 \
  --clump-r2 0.1 \
  --clump-kb 250 \
  --out "$OUTDIR/clumped" \
  --memory 16000

# Switch to scoring plink
module unload plink/2.00a5.8
module load plink/2.00-20231024-avx2

# Extract clumped SNP IDs
awk 'NR>1 {print $3}' "$OUTDIR/clumped.clumps" > "$OUTDIR/clumped_snps.txt"
echo "Clumped SNPs total: $(wc -l < "$OUTDIR/clumped_snps.txt")"

# Score at each threshold using clumped SNPs filtered by p-value
declare -A THRESHOLDS=(
  [5e-8]="5e-8"
  [1e-6]="1e-6"
  [1e-5]="1e-5"
  [1e-4]="1e-4"
  [5e-4]="5e-4"
  [1e-3]="1e-3"
  [1e-2]="1e-2"
  [5e-2]="5e-2"
  [0.1]="0.1"
  [0.5]="0.5"
  [1.0]="1.0"
)

for thr in 5e-8 1e-6 1e-5 1e-4 5e-4 1e-3 1e-2 5e-2 0.1 0.5 1.0; do
  # Filter clumped SNPs to those with p <= threshold
  python3 -c "
import sys
thr = float('$thr')
gwas = {}
with open('$OUTDIR/gwas_for_clump.txt') as f:
    next(f)
    for line in f:
        parts = line.split()
        if len(parts) >= 2:
            try: gwas[parts[0]] = float(parts[1])
            except: pass
with open('$OUTDIR/clumped_snps.txt') as f:
    snps = [l.strip() for l in f if l.strip()]
keep = [s for s in snps if gwas.get(s, 1.1) <= thr]
for s in keep: print(s)
" > "$OUTDIR/snps_${thr}.txt"

  n_snps=$(wc -l < "$OUTDIR/snps_${thr}.txt")
  echo "Threshold $thr: $n_snps SNPs"
  if [ "$n_snps" -eq 0 ]; then
    echo "  Skipping threshold $thr (0 SNPs)"
    continue
  fi

  plink2 \
    --bfile "$BED" \
    --score "$MA_FILE" 1 2 5 header-read \
    --extract "$OUTDIR/snps_${thr}.txt" \
    --memory 16000 \
    --out "$OUTDIR/ct_${thr}"
done

echo "End: $(date)"
echo "=== C+T done ==="
