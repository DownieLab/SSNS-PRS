#!/usr/bin/env Rscript
# Evaluate C+T at pre-specified p<5e-8 (genome-wide significance) for SSNS and ALB.
# No train/test split — threshold is pre-specified, not data-selected.
# Also evaluates full threshold sweep on all N=8,904 samples.
# Runs HLA exclusion for ALB C+T p<5e-8.
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(pROC)
})

BASE    <- '/lustre09/project/6076774/mbhnzi'
PHENO   <- file.path(BASE, 'archive/agent1/multi_ancestry/pheno_combined.txt')
PCA20   <- file.path(BASE, 'final_results/prs_v3/pca/pca_v3_20pc.eigenvec')
SSNS_CT <- file.path(BASE, 'prs_ssns_final/results/cv_filtered/ct_prs')
ALB_CT  <- file.path(BASE, 'prs_alb_final/results/cv_filtered/ct_prs')
HLA_DIR <- file.path(BASE, 'prs_ssns_final/results/window_comparison/hla_test')
BED     <- file.path(BASE, 'prs_ssns_final/data/combined_eur_sl_filtered')
ALB_MA  <- file.path(BASE, 'prs_alb_final/results/cv_filtered/ct_prs/ct_thresh_5em8.ma')

cat(sprintf('=== C+T p<5e-8 evaluation — %s ===\n', Sys.time()))

# ── Load phenotype + PCs ───────────────────────────────────────────────────────
pheno <- fread(PHENO); setnames(pheno, c('FID','IID','SSNS'))
pca20 <- fread(PCA20); setnames(pca20, c('FID','IID', paste0('PC',1:20)))
dat   <- merge(pheno[!is.na(SSNS)], pca20, by=c('FID','IID'))
cat(sprintf('N=%d  cases=%d  controls=%d\n', nrow(dat), sum(dat$SSNS), sum(dat$SSNS==0)))
pc_cols <- paste0('PC', 1:20)

# ── Score loader ───────────────────────────────────────────────────────────────
load_score <- function(f) {
  s <- fread(f, colClasses='character')
  if ('#FID' %in% names(s)) setnames(s, '#FID', 'FID')
  sc <- grep('AVG$|^b_', names(s), value=TRUE)[1]
  s[[sc]] <- suppressWarnings(as.numeric(s[[sc]]))
  s[, .(FID, IID, score=.SD[[sc]]), .SDcols=sc]
}

# ── Evaluate: all N=8904, no split ─────────────────────────────────────────────
eval_full <- function(score_vec, y_vec, pc_mat) {
  ok <- is.finite(score_vec) & !is.na(y_vec)
  auc_prs <- round(suppressMessages(as.numeric(roc(y_vec[ok], score_vec[ok])$auc)), 3)
  df <- data.frame(y=y_vec[ok], prs=scale(score_vec[ok])[,1], pc_mat[ok,,drop=FALSE])
  names(df)[-(1:2)] <- pc_cols
  m  <- glm(y~., data=df, family=binomial())
  co <- unname(coef(summary(m))['prs',])
  list(auc=auc_prs,
       or   = round(exp(co[1]), 3),
       ci_lo= round(exp(co[1] - 1.96*co[2]), 3),
       ci_hi= round(exp(co[1] + 1.96*co[2]), 3),
       p    = signif(co[4], 3))
}

merge_and_eval <- function(score_dt, pheno_dat) {
  d  <- merge(pheno_dat, score_dt, by=c('FID','IID'))
  pc <- as.matrix(d[, ..pc_cols])
  eval_full(d$score, as.integer(d$SSNS), pc)
}

# ── All thresholds ─────────────────────────────────────────────────────────────
thresholds <- c('5em8','1em6','1em5','1em4','5em4','0_001','0_01','0_05','0_1','0_5','1_0')
thr_labels <- c('5×10⁻⁸','1×10⁻⁶','1×10⁻⁵','1×10⁻⁴','5×10⁻⁴','0.001','0.01','0.05','0.1','0.5','1.0')

snp_counts <- function(ma_dir, thr) {
  f <- file.path(ma_dir, sprintf('ct_thresh_%s.ma', thr))
  if (!file.exists(f)) return(NA_integer_)
  max(0L, as.integer(system(sprintf('wc -l < %s', f), intern=TRUE)) - 1L)
}

cat('\n')
cat(rep('=', 80), '\n', sep='')
cat('SSNS — C+T all thresholds (all N=8,904, no split, 20 PCs)\n')
cat(rep('=', 80), '\n', sep='')
cat(sprintf('%-12s %6s %8s %8s %16s %12s\n',
            'Threshold', 'SNPs', 'AUC', 'OR', '95% CI', 'P-value'))
cat(rep('-', 70), '\n', sep='')

ssns_rows <- list()
for (i in seq_along(thresholds)) {
  thr <- thresholds[i]; lbl <- thr_labels[i]
  f   <- file.path(SSNS_CT, sprintf('ct_%s.sscore', thr))
  n   <- snp_counts(SSNS_CT, thr)
  if (!file.exists(f) || is.na(n) || n == 0) next
  s   <- load_score(f)
  r   <- merge_and_eval(s, dat)
  cat(sprintf('%-12s %6d %8.3f %8.3f %7.3f–%-7.3f %12s\n',
              lbl, n, r$auc, r$or, r$ci_lo, r$ci_hi, r$p))
  ssns_rows[[thr]] <- c(threshold=lbl, snps=n, auc=r$auc, or=r$or,
                         ci_lo=r$ci_lo, ci_hi=r$ci_hi, p=r$p)
}

cat('\n')
cat(rep('=', 80), '\n', sep='')
cat('ALB — C+T all thresholds (all N=8,904, no split, 20 PCs)\n')
cat(rep('=', 80), '\n', sep='')
cat(sprintf('%-12s %6s %8s %8s %16s %12s\n',
            'Threshold', 'SNPs', 'AUC', 'OR', '95% CI', 'P-value'))
cat(rep('-', 70), '\n', sep='')

alb_rows <- list()
for (i in seq_along(thresholds)) {
  thr <- thresholds[i]; lbl <- thr_labels[i]
  f   <- file.path(ALB_CT, sprintf('ct_%s.sscore', thr))
  n   <- snp_counts(ALB_CT, thr)
  if (!file.exists(f) || is.na(n) || n == 0) next
  s   <- load_score(f)
  r   <- merge_and_eval(s, dat)
  cat(sprintf('%-12s %6d %8.3f %8.3f %7.3f–%-7.3f %12s\n',
              lbl, n, r$auc, r$or, r$ci_lo, r$ci_hi, r$p))
  alb_rows[[thr]] <- c(threshold=lbl, snps=n, auc=r$auc, or=r$or,
                        ci_lo=r$ci_lo, ci_hi=r$ci_hi, p=r$p)
}

# ── Primary comparison table ───────────────────────────────────────────────────
cat('\n')
cat(rep('=', 100), '\n', sep='')
cat('PRIMARY COMPARISON TABLE\n')
cat(rep('=', 100), '\n', sep='')
cat(sprintf('%-8s %-22s %8s %8s %8s %16s %12s\n',
            'Analysis', 'Method', 'SNPs', 'AUC', 'OR(20PC)', '95% CI', 'P-value'))
cat(rep('-', 90), '\n', sep='')

# SSNS
cat(sprintf('%-8s %-22s %8s %8.3f %8.3f %7.3f–%-7.3f %12s\n',
            'SSNS', 'Simple PRS', '658,392', 0.707, 3.456, 2.999, 3.982, '7.3e-66'))
if (!is.null(ssns_rows[['5em8']])) {
  r <- ssns_rows[['5em8']]
  cat(sprintf('%-8s %-22s %8d %8.3f %8.3f %7.3f–%-7.3f %12s\n',
              'SSNS', 'C+T p<5e-8', as.integer(r['snps']),
              as.numeric(r['auc']), as.numeric(r['or']),
              as.numeric(r['ci_lo']), as.numeric(r['ci_hi']), r['p']))
}
cat(sprintf('%-8s %-22s %8s %8.3f %8.3f %7.3f–%-7.3f %12s\n',
            'SSNS', 'LDpred2 Config1', '586,299', 0.750, 2.939, 2.648, 3.261, '9.1e-92'))
cat(rep('-', 90), '\n', sep='')

# ALB
cat(sprintf('%-8s %-22s %8s %8.3f %8.3f %7.3f–%-7.3f %12s\n',
            'ALB', 'Simple PRS', '508,459', 0.523, 0.881, 0.815, 0.951, '0.00126'))
if (!is.null(alb_rows[['5em8']])) {
  r <- alb_rows[['5em8']]
  cat(sprintf('%-8s %-22s %8d %8.3f %8.3f %7.3f–%-7.3f %12s\n',
              'ALB', 'C+T p<5e-8', as.integer(r['snps']),
              as.numeric(r['auc']), as.numeric(r['or']),
              as.numeric(r['ci_lo']), as.numeric(r['ci_hi']), r['p']))
}
cat(sprintf('%-8s %-22s %8s %8.3f %8.3f %7.3f–%-7.3f %12s\n',
            'ALB', 'LDpred2 Config1', '484,655', 0.543, 0.929, 0.861, 1.004, '0.063'))

# ── HLA exclusion: ALB C+T p<5e-8 ────────────────────────────────────────────
cat('\n')
cat(rep('=', 80), '\n', sep='')
cat('HLA EXCLUSION — ALB C+T p<5e-8 (chr6:25-34Mb)\n')
cat(rep('=', 80), '\n', sep='')

# Compute HLA-only score if not already done
hla_out <- file.path(HLA_DIR, 'ct_5em8_hla_only')
if (!file.exists(paste0(hla_out, '.sscore'))) {
  cat('Running PLINK2 to compute HLA-only contribution...\n')
  cmd <- sprintf(
    'plink2 --bfile %s --score %s 1 2 5 header-read --extract %s --memory 40000 --threads 1 --out %s',
    BED, ALB_MA, file.path(HLA_DIR, 'hla_snps_bim.txt'), hla_out)
  system(cmd)
}

if (file.exists(paste0(hla_out, '.sscore'))) {
  # HLA-only SNP count
  n_hla_5e8 <- max(0L, as.integer(system(sprintf('grep -c . %s', ALB_MA), intern=TRUE)) - 1L)
  alb_5e8_full <- load_score(file.path(ALB_CT, 'ct_5em8.sscore'))
  alb_5e8_hla  <- load_score(paste0(hla_out, '.sscore'))
  setnames(alb_5e8_hla,  'score', 'hla_score')
  merged_hla <- merge(alb_5e8_full, alb_5e8_hla, by=c('FID','IID'))
  merged_hla[, score_nohla := score - hla_score]

  d_full  <- merge(dat, merged_hla[, .(FID, IID, score, score_nohla)], by=c('FID','IID'))
  pc_mat  <- as.matrix(d_full[, ..pc_cols])

  r_incl <- eval_full(d_full$score,        as.integer(d_full$SSNS), pc_mat)
  r_excl <- eval_full(d_full$score_nohla,  as.integer(d_full$SSNS), pc_mat)

  # Count HLA SNPs actually scored
  hla_log <- paste0(hla_out, '.log')
  n_hla_scored <- tryCatch({
    lg <- readLines(hla_log)
    hit <- grep('variants processed', lg, value=TRUE)
    as.integer(gsub('[^0-9]', '', hit[length(hit)]))
  }, error=function(e) NA_integer_)

  cat(sprintf('\n%-22s %8s %10s %6s %14s %10s %6s %14s\n',
              'Method', 'HLA_SNPs', 'OR(w/HLA)', 'P', 'CI(w/HLA)',
              'OR(no/HLA)', 'P', 'CI(no/HLA)'))
  cat(rep('-', 85), '\n', sep='')
  cat(sprintf('%-22s %8d %10.3f %6s %7.3f–%-6.3f %10.3f %6s %7.3f–%.3f\n',
              'C+T p<5e-8', n_hla_scored,
              r_incl$or, r_incl$p, r_incl$ci_lo, r_incl$ci_hi,
              r_excl$or, r_excl$p, r_excl$ci_lo, r_excl$ci_hi))
} else {
  cat('ERROR: PLINK2 HLA scoring failed — check log\n')
}

cat(sprintf('\n=== Done — %s ===\n', Sys.time()))
