#!/bin/bash
#SBATCH --job-name=eval_ct5e8
#SBATCH --account=def-mdownie
#SBATCH --time=0:20:00
#SBATCH --mem=16G
#SBATCH --cpus-per-task=1
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/eval_ct5e8_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/eval_ct5e8_%j.err

echo "Start: $(date)"
module load r/4.5.0 plink/2.0.0-a.6.32
export OMP_NUM_THREADS=1

Rscript /lustre09/project/6076774/mbhnzi/pub_repo/scripts/eval_ct_5e8.R
echo "End: $(date)"
