#!/usr/bin/env Rscript
# Generate final publication figures.
# C+T uses pre-specified p<5e-8 (no model selection).
# LDpred2 uses best model from 5-fold CV (SSNS=PRS_3, ALB=PRS_1).
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(pROC); library(ggplot2)
})

BASE   <- '/lustre09/project/6076774/mbhnzi'
OUTDIR <- '/lustre09/project/6076774/mbhnzi/pub_repo/plots'
PHENO  <- file.path(BASE, 'archive/agent1/multi_ancestry/pheno_combined.txt')
PCA20  <- file.path(BASE, 'final_results/prs_v3/pca/pca_v3_20pc.eigenvec')

COL_SIMPLE <- '#2980B9'
COL_CT     <- '#E67E22'
COL_LD     <- '#2C3E50'

pheno <- fread(PHENO); setnames(pheno, c('FID','IID','SSNS'))
pca20 <- fread(PCA20); setnames(pca20, c('FID','IID', paste0('PC',1:20)))
dat   <- merge(pheno[!is.na(SSNS)], pca20, by=c('FID','IID'))
cat(sprintf('N=%d  cases=%d  controls=%d\n', nrow(dat), sum(dat$SSNS), sum(dat$SSNS==0)))

load_ss <- function(f) {
  s <- fread(f, colClasses='character')
  if ('#FID' %in% names(s)) setnames(s, '#FID', 'FID')
  for (cc in grep('AVG$|^b_|^PRS', names(s), value=TRUE))
    s[[cc]] <- suppressWarnings(as.numeric(s[[cc]]))
  s
}
get_score <- function(score_dt, col) {
  d <- merge(dat[, .(FID, IID, SSNS)],
             score_dt[, .SD, .SDcols=c('FID','IID',col)], by=c('FID','IID'))
  list(sc=as.numeric(d[[col]]), y=as.integer(d$SSNS))
}
roc_obj <- function(sc, y) {
  ok <- is.finite(sc)
  r  <- suppressMessages(pROC::roc(y[ok], sc[ok]))
  list(df=data.table(fpr=1-r$specificities, tpr=r$sensitivities), auc=as.numeric(r$auc))
}

roc_theme <- theme_bw(base_size=12) +
  theme(legend.position=c(0.98, 0.02), legend.justification=c('right','bottom'),
        legend.background=element_rect(fill='white', color='gray70', linewidth=0.5),
        legend.key=element_rect(fill='white'), legend.key.width=unit(1.6,'cm'),
        legend.text=element_text(size=9, family='mono'), panel.grid.minor=element_blank())

make_roc_plot <- function(s_r, c_r, l_r, title_str, ct_label='C+T p<5×10⁻⁸') {
  lbl_s <- sprintf('Simple PRS     AUC=%.3f', s_r$auc)
  lbl_c <- sprintf('%-14s AUC=%.3f', ct_label, c_r$auc)
  lbl_l <- sprintf('LDpred2 C1-3k  AUC=%.3f', l_r$auc)
  lvls  <- c(lbl_s, lbl_c, lbl_l)
  cols  <- setNames(c(COL_SIMPLE, COL_CT, COL_LD), lvls)
  df <- rbind(cbind(s_r$df, method=lbl_s), cbind(c_r$df, method=lbl_c),
              cbind(l_r$df, method=lbl_l))
  df$method <- factor(df$method, levels=lvls)
  ggplot(df, aes(x=fpr, y=tpr, color=method)) +
    annotate('segment', x=0, y=0, xend=1, yend=1, color='gray70', linewidth=0.8, linetype=2) +
    geom_line(lwd=1.5) +
    scale_color_manual(values=cols, name=NULL) +
    scale_x_continuous(limits=c(0,1), expand=c(0.01,0.01)) +
    scale_y_continuous(limits=c(0,1), expand=c(0.01,0.01)) +
    coord_equal() +
    labs(x='1 – Specificity', y='Sensitivity', title=title_str) +
    roc_theme
}

# ── Load score files ──────────────────────────────────────────────────────────
cat('\nLoading score files...\n')

ssns_simple <- load_ss(file.path(BASE,'prs_ssns_final/results/cv_filtered/simple_prs/simple_prs.sscore'))
ssns_sc <- grep('AVG$|^b_', names(ssns_simple), value=TRUE)[1]
setnames(ssns_simple, ssns_sc, 'PRS_1')

alb_simple <- load_ss(file.path(BASE,'prs_alb_final/results/cv_filtered/simple_prs/simple_prs.sscore'))
alb_sc <- grep('AVG$|^b_', names(alb_simple), value=TRUE)[1]
setnames(alb_simple, alb_sc, 'PRS_1')

# C+T: pre-specified p<5e-8
ssns_ct5e8 <- load_ss(file.path(BASE,'prs_ssns_final/results/cv_filtered/ct_prs/ct_5em8.sscore'))
ssns_ct_sc <- grep('AVG$|^b_', names(ssns_ct5e8), value=TRUE)[1]
setnames(ssns_ct5e8, ssns_ct_sc, 'score')

alb_ct5e8  <- load_ss(file.path(BASE,'prs_alb_final/results/cv_filtered/ct_prs/ct_5em8.sscore'))
alb_ct_sc  <- grep('AVG$|^b_', names(alb_ct5e8), value=TRUE)[1]
setnames(alb_ct5e8, alb_ct_sc, 'score')

# LDpred2 best: SSNS=PRS_3 (p=0.01), ALB=PRS_1 (p=1e-4)
ssns_ld <- load_ss(file.path(BASE,'prs_ssns_final/results/window_comparison/ssns_size3000/config1.sscore'))
alb_ld  <- load_ss(file.path(BASE,'prs_ssns_final/results/window_comparison/alb_size3000/config1.sscore'))

# ── ROC: SSNS ────────────────────────────────────────────────────────────────
cat('\n--- SSNS ROC ---\n')
ssns_s_r <- roc_obj(get_score(ssns_simple, 'PRS_1')$sc, get_score(ssns_simple, 'PRS_1')$y)
ssns_c_r <- roc_obj(get_score(ssns_ct5e8,  'score')$sc, get_score(ssns_ct5e8,  'score')$y)
ssns_l_r <- roc_obj(get_score(ssns_ld,     'PRS_3')$sc, get_score(ssns_ld,     'PRS_3')$y)
cat(sprintf('  Simple=%.3f  C+T_5e8=%.3f  LDpred2=%.3f\n',
            ssns_s_r$auc, ssns_c_r$auc, ssns_l_r$auc))
ggsave(file.path(OUTDIR,'roc_ssns.png'),
       make_roc_plot(ssns_s_r, ssns_c_r, ssns_l_r, 'SSNS PRS — ROC Curves (PRS only)'),
       width=7, height=6, dpi=300)
cat('  roc_ssns.png saved\n')

# ── ROC: ALB ─────────────────────────────────────────────────────────────────
cat('\n--- ALB ROC ---\n')
alb_s_r <- roc_obj(get_score(alb_simple, 'PRS_1')$sc, get_score(alb_simple, 'PRS_1')$y)
alb_c_r <- roc_obj(get_score(alb_ct5e8,  'score')$sc, get_score(alb_ct5e8,  'score')$y)
alb_l_r <- roc_obj(get_score(alb_ld,     'PRS_1')$sc, get_score(alb_ld,     'PRS_1')$y)
cat(sprintf('  Simple=%.3f  C+T_5e8=%.3f  LDpred2=%.3f\n',
            alb_s_r$auc, alb_c_r$auc, alb_l_r$auc))
ggsave(file.path(OUTDIR,'roc_alb.png'),
       make_roc_plot(alb_s_r, alb_c_r, alb_l_r,
                    'Albuminuria PRS → SSNS — ROC Curves (PRS only)'),
       width=7, height=6, dpi=300)
cat('  roc_alb.png saved\n')

# ── Forest plot ───────────────────────────────────────────────────────────────
cat('\n--- Forest plot ---\n')
hla_res <- fread(file.path(BASE,'pub_repo/results/alb/hla_exclusion_results.tsv'))
ct_res  <- fread(file.path(BASE,'pub_repo/results/ssns/simple_ct_5fold_results.tsv'))

parse_ci <- function(ci_str) {
  p <- strsplit(ci_str, '-')[[1]]
  list(lo=as.numeric(p[1]), hi=as.numeric(p[2]))
}
hr_s <- hla_res[grepl('Simple', Method)]
hr_l <- hla_res[grepl('LDpred2', Method)]
ci_s_i <- parse_ci(hr_s$CI_incl_cv); ci_s_e <- parse_ci(hr_s$CI_excl_cv)
ci_l_i <- parse_ci(hr_l$CI_incl_cv); ci_l_e <- parse_ci(hr_l$CI_excl_cv)

fp <- rbind(
  # SSNS
  data.table(group='SSNS', method='Simple PRS',       or=3.456, lo=2.999, hi=3.982),
  data.table(group='SSNS', method='C+T p<5×10⁻⁸', or=2.283, lo=2.094, hi=2.489),
  data.table(group='SSNS', method='LDpred2 Config1',  or=2.939, lo=2.648, hi=3.261),
  # ALB with HLA
  data.table(group='ALB (with HLA)',  method='Simple PRS',      or=hr_s$OR_incl_cv, lo=ci_s_i$lo, hi=ci_s_i$hi),
  data.table(group='ALB (with HLA)',  method='C+T p<5×10⁻⁸', or=1.009, lo=0.932, hi=1.092),
  data.table(group='ALB (with HLA)',  method='LDpred2 Config1', or=hr_l$OR_incl_cv, lo=ci_l_i$lo, hi=ci_l_i$hi),
  # ALB without HLA
  data.table(group='ALB (HLA excluded)', method='Simple PRS',      or=hr_s$OR_excl_cv, lo=ci_s_e$lo, hi=ci_s_e$hi),
  data.table(group='ALB (HLA excluded)', method='C+T p<5×10⁻⁸', or=1.009, lo=0.932, hi=1.092),
  data.table(group='ALB (HLA excluded)', method='LDpred2 Config1', or=hr_l$OR_excl_cv, lo=ci_l_e$lo, hi=ci_l_e$hi)
)
fp[, method  := factor(method,  levels=rev(c('Simple PRS','C+T p<5×10⁻⁸','LDpred2 Config1')))]
fp[, group_f := factor(group, levels=c('SSNS','ALB (with HLA)','ALB (HLA excluded)'))]
fp[, label   := sprintf('%.3f [%.3f–%.3f]', or, lo, hi)]
print(fp[, .(group, method, or, lo, hi)])

g_forest <- ggplot(fp, aes(y=method, x=or, xmin=lo, xmax=hi, color=group_f)) +
  geom_vline(xintercept=1, linetype='dashed', color='gray40', linewidth=0.5) +
  geom_errorbar(aes(xmin=lo, xmax=hi), height=0.25, linewidth=0.8, orientation='y') +
  geom_point(size=3) +
  geom_text(aes(label=label), hjust=-0.07, size=2.8, color='gray20') +
  scale_x_log10(breaks=c(0.7,0.8,0.9,1.0,1.5,2.0,2.5,3.0,4.0), limits=c(0.65,8)) +
  scale_color_manual(values=c('SSNS'='#2166AC','ALB (with HLA)'='#D73027',
                               'ALB (HLA excluded)'='#4DAC26'), name=NULL) +
  facet_grid(group_f~., scales='free_y', space='free_y') +
  labs(x='Odds Ratio (log scale, per SD PRS)', y=NULL,
       title='PRS associations with SSNS (all N=8,904, 20 PCs)') +
  theme_bw(base_size=11) +
  theme(legend.position='none', strip.background=element_rect(fill='gray92'),
        strip.text=element_text(face='bold', size=10), panel.grid.minor=element_blank())
ggsave(file.path(OUTDIR,'forest_plot.png'), g_forest, width=11, height=7, dpi=300)
cat('  forest_plot.png saved\n')

# ── C+T threshold sweep figure ────────────────────────────────────────────────
cat('\n--- C+T threshold sweep ---\n')
thr_levels <- c('5e-8','1e-6','1e-5','1e-4','5e-4','0.001','0.01','0.05','0.1','0.5','1.0')
thr_keys   <- c('5em8','1em6','1em5','1em4','5em4','0_001','0_01','0_05','0_1','0_5','1_0')
thr_p      <- c(5e-8, 1e-6, 1e-5, 1e-4, 5e-4, 0.001, 0.01, 0.05, 0.1, 0.5, 1.0)
SSNS_CT    <- file.path(BASE,'prs_ssns_final/results/cv_filtered/ct_prs')
ALB_CT     <- file.path(BASE,'prs_alb_final/results/cv_filtered/ct_prs')
pc_cols    <- paste0('PC',1:20)

eval_full_or <- function(f) {
  if (!file.exists(f)) return(NULL)
  s  <- load_ss(f); sc_col <- grep('AVG$|^b_|^score', names(s), value=TRUE)[1]
  d  <- merge(dat, s[, .SD, .SDcols=c('FID','IID',sc_col)], by=c('FID','IID'))
  sc <- as.numeric(d[[sc_col]]); ok <- is.finite(sc)
  if (sum(ok) < 10) return(NULL)
  df <- data.frame(y=as.integer(d$SSNS[ok]), prs=scale(sc[ok])[,1],
                   as.matrix(d[ok, ..pc_cols]))
  names(df)[-(1:2)] <- pc_cols
  m  <- glm(y~., data=df, family=binomial())
  co <- unname(coef(summary(m))['prs',])
  data.table(or=exp(co[1]), lo=exp(co[1]-1.96*co[2]), hi=exp(co[1]+1.96*co[2]))
}

sweep_rows <- lapply(seq_along(thr_keys), function(i) {
  thr <- thr_keys[i]
  s <- eval_full_or(file.path(SSNS_CT, sprintf('ct_%s.sscore', thr)))
  a <- eval_full_or(file.path(ALB_CT,  sprintf('ct_%s.sscore', thr)))
  if (is.null(s) || is.null(a)) return(NULL)
  rbind(cbind(pheno='SSNS', p_val=thr_p[i], thr_label=thr_levels[i], s),
        cbind(pheno='ALB',  p_val=thr_p[i], thr_label=thr_levels[i], a))
})
sweep_dt <- rbindlist(Filter(Negate(is.null), sweep_rows))
sweep_dt[, p_val    := as.numeric(p_val)]
sweep_dt[, thr_label := factor(thr_label, levels=thr_levels)]

g_sweep <- ggplot(sweep_dt, aes(x=p_val, y=or, color=pheno, fill=pheno)) +
  geom_hline(yintercept=1, linetype='dashed', color='gray40', linewidth=0.5) +
  geom_ribbon(aes(ymin=lo, ymax=hi), alpha=0.15, color=NA) +
  geom_line(linewidth=1.2) +
  geom_point(size=2.5) +
  scale_x_log10(breaks=thr_p,
                labels=c('5e-8','1e-6','1e-5','1e-4','5e-4','0.001','0.01','0.05','0.1','0.5','1.0')) +
  scale_color_manual(values=c('SSNS'='#2166AC','ALB'='#D73027'), name='Phenotype') +
  scale_fill_manual(values=c('SSNS'='#2166AC','ALB'='#D73027'), name='Phenotype') +
  labs(x='C+T p-value threshold', y='OR per SD PRS (20 PCs)',
       title='C+T OR across p-value thresholds (all N=8,904)') +
  theme_bw(base_size=12) +
  theme(axis.text.x=element_text(angle=35, hjust=1), panel.grid.minor=element_blank())
ggsave(file.path(OUTDIR,'ct_threshold_sweep.png'), g_sweep, width=9, height=5.5, dpi=300)
cat('  ct_threshold_sweep.png saved\n')

# ── LDpred2 Config1 heatmap ───────────────────────────────────────────────────
cat('\n--- LDpred2 Config1 heatmap ---\n')
ssns_h2 <- 0.0756788382460413   # 1.0× LDSC h² for SSNS
alb_h2  <- 0.013403496637899    # 1.0× LDSC h² for ALB

heat_panel <- function(score_f, params_f, h2_init, label) {
  s <- load_ss(score_f); p <- fread(params_f)
  d <- merge(dat[, .(FID,IID,SSNS)], s, by=c('FID','IID')); y <- as.integer(d$SSNS)
  p[, auc := sapply(seq_len(.N), function(j) {
    sc <- as.numeric(d[[paste0('PRS_',j)]])
    if (!any(is.finite(sc))) return(NA_real_)
    tryCatch(suppressMessages(as.numeric(roc(y, sc)$auc)), error=function(e) NA_real_)
  })]
  p[, phenotype := label]; p[, h2_mult := round(h2/h2_init,2)]
  p[, p_label := sprintf('%.0e', p)]; p
}
heat_all <- rbind(
  heat_panel(file.path(BASE,'prs_ssns_final/results/window_comparison/ssns_size3000/config1.sscore'),
             file.path(BASE,'prs_ssns_final/results/window_comparison/ssns_size3000/config1_params.tsv'),
             ssns_h2, 'SSNS'),
  heat_panel(file.path(BASE,'prs_ssns_final/results/window_comparison/alb_size3000/config1.sscore'),
             file.path(BASE,'prs_ssns_final/results/window_comparison/alb_size3000/config1_params.tsv'),
             alb_h2, 'ALB'))
heat_all[, p_label  := factor(p_label, levels=unique(p_label[order(p)]))]
heat_all[, h2_label := paste0(h2_mult,'×h²')]
heat_all[, h2_label := factor(h2_label, levels=unique(h2_label[order(h2_mult)]))]
heat_all[, is_best  := FALSE]
heat_all[phenotype=='SSNS', is_best := auc==max(auc, na.rm=TRUE)]
heat_all[phenotype=='ALB',  is_best := auc==max(auc, na.rm=TRUE)]
g_heat <- ggplot(heat_all, aes(x=p_label, y=h2_label, fill=auc)) +
  geom_tile(color='white', linewidth=0.4) +
  geom_text(aes(label=ifelse(is.na(auc),'',sprintf('%.3f',auc))), size=2.8, color='white') +
  geom_point(data=heat_all[is_best==TRUE], aes(x=p_label,y=h2_label),
             shape=8, size=4, color='yellow', inherit.aes=FALSE) +
  scale_fill_gradient2(low='#2166AC', mid='#F7F7F7', high='#D73027',
                       midpoint=0.6, na.value='gray80', name='AUC') +
  facet_wrap(~phenotype, ncol=2) +
  labs(x='p (causal proportion)', y='h² multiplier', title='LDpred2 Config1 Grid AUC') +
  theme_bw(base_size=11) +
  theme(panel.grid=element_blank(), strip.background=element_rect(fill='gray92'),
        strip.text=element_text(face='bold'))
ggsave(file.path(OUTDIR,'ldpred2_heatmap.png'), g_heat, width=12, height=5, dpi=300)
cat('  ldpred2_heatmap.png saved\n')

cat(sprintf('\n=== All figures done — %s ===\n', Sys.time()))
