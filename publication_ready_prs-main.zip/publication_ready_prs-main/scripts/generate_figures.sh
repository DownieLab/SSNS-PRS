#!/bin/bash
#SBATCH --job-name=gen_figs
#SBATCH --account=def-mdownie
#SBATCH --time=0:30:00
#SBATCH --mem=32G
#SBATCH --cpus-per-task=1
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/gen_figs_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/gen_figs_%j.err

echo "Start: $(date)"
module load r/4.5.0
export OMP_NUM_THREADS=1

Rscript /lustre09/project/6076774/mbhnzi/pub_repo/scripts/generate_figures.R
echo "End: $(date)"
