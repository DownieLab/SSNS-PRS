#!/bin/bash
#SBATCH --job-name=gwas_batch
#SBATCH --account=def-mdownie
#SBATCH --time=01:30:00
#SBATCH --cpus-per-task=4
#SBATCH --mem=32G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/gwas_batch_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_ssns_final/logs/gwas_batch_%j.err

module load plink/2.0.0-a.6.32
echo "Start: $(date)"

BED=/lustre09/project/6076774/mbhnzi/prs_ssns_final/data/combined_eur_sl_filtered
PHENO=/lustre09/project/6076774/mbhnzi/archive/agent1/multi_ancestry/pheno_combined.txt
COVAR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/gwas/covar_pcs_batch.txt
OUTDIR=/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/gwas

# Covariate file: FID IID PC1..PC10 BATCH
# Cols 3-13 = PC1-10 + BATCH (EUR_other indicator)
plink2 --1 \
  --bfile $BED \
  --pheno $PHENO \
  --pheno-name SSNS \
  --covar $COVAR \
  --covar-col-nums 3-13 \
  --covar-variance-standardize \
  --glm hide-covar --geno 0.05 --maf 0.01 --hwe 1e-6 \
  --out $OUTDIR/gwas_batch_corrected \
  --threads $SLURM_CPUS_PER_TASK --memory 28000

echo "End: $(date)"
