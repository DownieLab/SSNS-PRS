#!/usr/bin/env Rscript
# Regenerate 3-panel Manhattan using filtered GWAS for Panel C.
# Panels A and B are unchanged from previous run.
.libPaths(c('/project/def-mdownie/mbhnzi/Shared_Resources/R_libs', .libPaths()))
suppressPackageStartupMessages({
  library(data.table); library(ggplot2); library(cowplot)
})

cat(sprintf('=== Update Manhattan — %s ===\n', Sys.time()))

BARRY_FILE  <- '/lustre09/project/6076774/mbhnzi/data/ssns/barry_realigned.txt'
METAL_FILE  <- '/lustre09/project/6076774/mbhnzi/final_results/meta_metal_results2_1.tbl'
TEU_FILE    <- '/lustre09/project/6076774/mbhnzi/data/teumer/teumer_for_metal.txt'
BRD_FILE    <- '/lustre09/project/6076774/mbhnzi/data/brandenburg/brandenburg_for_metal.txt'
TARGET_FILE <- '/lustre09/project/6076774/mbhnzi/prs_ssns_final/results/gwas/gwas_filtered.SSNS.glm.logistic.hybrid'
PLOT_DIR    <- '/lustre09/project/6076774/mbhnzi/pub_repo/plots'
dir.create(PLOT_DIR, recursive = TRUE, showWarnings = FALSE)

valid_chrs <- as.character(1:22)
CHR_COLS   <- c('odd' = '#0D2240', 'even' = '#2E75B6')
GWS_THRESH <- -log10(5e-8)

# ── chr:pos lookup for Panel B ────────────────────────────────────────────────
load_cohort <- function(path) {
  dt <- fread(path, sep = '\t',
              select = c('MarkerName', 'Chr', 'Position'),
              colClasses = list(character = c('MarkerName', 'Chr'), integer = 'Position'))
  setnames(dt, c('rsid', 'chr', 'pos'))
  dt[, rsid := gsub('"', '', rsid)]
  dt <- dt[grepl('^rs[0-9]+$', rsid) & chr %in% valid_chrs & !is.na(pos) & pos > 0]
  incon <- unique(dt, by = c('rsid', 'chr', 'pos'))[duplicated(rsid) | duplicated(rsid, fromLast = TRUE), unique(rsid)]
  unique(dt[!rsid %in% incon], by = 'rsid')
}

cat('Building chr:pos lookup...\n')
teu    <- load_cohort(TEU_FILE)
brd    <- load_cohort(BRD_FILE)
both   <- merge(teu, brd, by = 'rsid', suffixes = c('_t', '_b'))
conflict <- both[chr_t != chr_b | pos_t != pos_b, rsid]
lookup <- unique(rbind(teu[!rsid %in% conflict], brd[!rsid %in% conflict]), by = 'rsid')
lookup[, chr := as.integer(chr)]

metal <- fread(METAL_FILE, select = c('MarkerName', 'P-value'))
setnames(metal, c('rsid', 'p'))
metal[, p := as.numeric(p)]
metal <- metal[is.finite(p) & p > 0 & p <= 1]
alb_manh <- merge(metal, lookup[, .(rsid, chr, pos)], by = 'rsid')
cat(sprintf('Panel B: %d SNPs, min p = %.3e\n', nrow(alb_manh), min(alb_manh$p)))

# ── Manhattan helpers ─────────────────────────────────────────────────────────
prep_manh <- function(dt) {
  dt <- dt[chr %in% 1:22 & is.finite(p) & p > 0]
  dt[, chr := as.integer(chr)]
  chr_max <- dt[, .(max_pos = max(as.numeric(pos))), by = chr][order(chr)]
  chr_max[, offset := c(0, cumsum(as.numeric(max_pos))[-nrow(chr_max)])]
  dt <- merge(dt, chr_max[, .(chr, offset)], by = 'chr', sort = FALSE)
  dt[, cum_pos := as.numeric(pos) + offset]
  dt[, logp    := -log10(p)]
  dt[, chrcol  := factor(chr %% 2, levels = c(1, 0), labels = c('odd', 'even'))]
  dt[, gws     := logp >= GWS_THRESH]
  mids <- dt[, .(mid = mean(range(cum_pos))), by = chr][order(chr)]
  list(dt = dt, mids = mids)
}

top_labels <- function(dt, id_col = 'rsid', max_labels = 10, min_dist = 2e6) {
  hits <- dt[p < 5e-8][order(p)]
  if (nrow(hits) == 0) return(data.table())
  keep <- hits[1]; hits <- hits[-1]
  for (i in seq_len(nrow(hits))) {
    row <- hits[i]
    if (all(abs(keep$cum_pos - row$cum_pos) > min_dist)) keep <- rbind(keep, row)
    if (nrow(keep) >= max_labels) break
  }
  keep[, lab := if (id_col %in% names(keep)) get(id_col) else paste0(chr, ':', pos)]
  keep
}

manh_plot <- function(dt, mids, title, ylim_max, labels = NULL) {
  p <- ggplot() +
    geom_point(data = dt[gws == FALSE], aes(x = cum_pos, y = logp, colour = chrcol),
               size = 0.55, stroke = 0, shape = 16) +
    geom_point(data = dt[gws == TRUE],  aes(x = cum_pos, y = logp),
               colour = '#B22222', size = 0.9, stroke = 0, shape = 16) +
    geom_hline(yintercept = GWS_THRESH, colour = '#CC0000', linetype = 'dashed', linewidth = 0.8) +
    scale_colour_manual(values = CHR_COLS, guide = 'none') +
    scale_x_continuous(breaks = mids$mid, labels = mids$chr, expand = c(0.005, 0)) +
    scale_y_continuous(limits = c(0, ylim_max), expand = c(0, 0)) +
    labs(title = title, x = 'Chromosome', y = expression(bold(-log[10](italic(p))))) +
    theme_classic(base_size = 10) +
    theme(panel.background = element_rect(fill = 'white'),
          plot.background  = element_rect(fill = 'white'),
          panel.grid       = element_blank(),
          axis.text.x  = element_text(size = 8, face = 'bold'),
          axis.text.y  = element_text(size = 8),
          axis.title   = element_text(size = 9, face = 'bold'),
          plot.title   = element_text(size = 9, face = 'bold'))
  if (!is.null(labels) && nrow(labels) > 0) {
    p <- p + geom_label(data = labels, aes(x = cum_pos, y = logp, label = lab),
                        inherit.aes = FALSE, size = 2.6, fontface = 'bold',
                        colour = 'black', fill = 'white', label.size = 0,
                        label.padding = unit(0.12, 'lines'), vjust = -0.4, hjust = 0.5)
  }
  p
}

# ── Panel A: Barry ────────────────────────────────────────────────────────────
cat('Panel A...\n')
barry <- fread(BARRY_FILE, select = c('ID', 'P'))
barry[, chr := as.integer(sub(':.*', '', ID))]
barry[, pos := as.numeric(sub('.*:', '', ID))]
barry[, p   := as.numeric(P)]
barry <- barry[!is.na(chr) & !is.na(pos) & !is.na(p) & p > 0 & chr %in% 1:22]
ba <- prep_manh(barry)
ba_lab <- top_labels(ba$dt, id_col = 'ID')
ba_lab[, lab := sub('(\\d+):(\\d+)', 'chr\\1:\\2', lab)]
pa <- manh_plot(ba$dt, ba$mids,
  'A: Barry et al. SSNS GWAS — N = 38,463 | 18,066,346 SNPs',
  ceiling(max(ba$dt$logp)) + 3, ba_lab)

# ── Panel B: Albuminuria ──────────────────────────────────────────────────────
cat('Panel B...\n')
bb <- prep_manh(alb_manh)
bb_lab <- top_labels(bb$dt, id_col = 'rsid')
pb <- manh_plot(bb$dt, bb$mids,
  'B: Albuminuria Meta-Analysis GWAS — N = 347,284 | 21,640,402 SNPs',
  ceiling(max(bb$dt$logp)) + 3, bb_lab)

# ── Panel C: Filtered target GWAS ────────────────────────────────────────────
# Chr15 is excluded: confirmed batch artifact from EUR_other (all-case) cohort
# having systematically different chr15 imputation vs WTCCC/OXF/ILLUM (control-heavy).
# Chr15 lambda=1.54 vs genome-wide 1.17; top hit p=1e-101 absent from Barry GWAS (N=38k).
cat('Panel C (filtered GWAS, chr15 excluded)...\n')
tgt <- fread(TARGET_FILE, select = c('#CHROM', 'POS', 'P'))
setnames(tgt, c('chr', 'pos', 'p'))
tgt[, chr := as.integer(chr)]
tgt[, pos := as.numeric(pos)]
tgt[, p   := as.numeric(p)]
tgt <- tgt[!is.na(chr) & !is.na(pos) & !is.na(p) & p > 0 & chr %in% 1:22 & chr != 15L]
cat(sprintf('  Target (chr15 excluded): %d SNPs, min p = %.3e\n', nrow(tgt), min(tgt$p)))
bc <- prep_manh(tgt)
bc_lab <- top_labels(bc$dt)
bc_lab[, lab := paste0('chr', chr, ':', pos)]
pc <- manh_plot(bc$dt, bc$mids,
  'C: Target Cohort GWAS (EUR+SL) — N = 8,904 | chr15 excluded (batch artifact)',
  ceiling(max(bc$dt$logp)) + 3, bc_lab)

# ── Assemble ──────────────────────────────────────────────────────────────────
cat('Assembling...\n')
combined <- plot_grid(pa, pb, pc, ncol = 1, align = 'v', rel_heights = c(1.1, 1.1, 1))
ggsave(file.path(PLOT_DIR, 'manhattan_3panel.png'),
       combined, width = 15, height = 14, dpi = 300, bg = 'white')
cat(sprintf('Saved: manhattan_3panel.png — %s\n', Sys.time()))
