#!/bin/bash
#SBATCH --job-name=update_manh
#SBATCH --account=def-mdownie
#SBATCH --time=02:00:00
#SBATCH --cpus-per-task=2
#SBATCH --mem=64G
#SBATCH --output=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/alb_update_manh_%j.out
#SBATCH --error=/lustre09/project/6076774/mbhnzi/prs_alb_final/logs/alb_update_manh_%j.err

module load r/4.5.0
echo "Start: $(date)"
Rscript /lustre09/project/6076774/mbhnzi/prs_alb_final/cv_scripts/update_manhattan.R
echo "End: $(date)"
